-- phpMyAdmin SQL Dump
-- version 2.10.2
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 26-08-2016 a las 17:14:30
-- Versión del servidor: 5.0.45
-- Versión de PHP: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `app_debie`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `area`
-- 

CREATE TABLE `area` (
  `id` int(11) NOT NULL auto_increment,
  `area` varchar(90) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `area`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `area_has_usuarios`
-- 

CREATE TABLE `area_has_usuarios` (
  `id` int(11) NOT NULL auto_increment,
  `id_area` int(11) NOT NULL,
  `id_usuarios` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_area` (`id_area`),
  KEY `id_usuarios` (`id_usuarios`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `area_has_usuarios`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `asistencia_estudiante`
-- 

CREATE TABLE `asistencia_estudiante` (
  `id` int(11) NOT NULL auto_increment,
  `id_estudiantes_bloques` int(11) NOT NULL,
  `estado` varchar(90) collate utf8_spanish_ci NOT NULL,
  `fecha` varchar(90) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_estudiantes_bloques` (`id_estudiantes_bloques`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `asistencia_estudiante`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `becarios_asignados`
-- 

CREATE TABLE `becarios_asignados` (
  `id` int(11) NOT NULL auto_increment,
  `id_estudiantes` int(11) NOT NULL,
  `id_usuarios` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_estudiantes` (`id_estudiantes`),
  KEY `id_usuarios` (`id_usuarios`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `becarios_asignados`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `bloques`
-- 

CREATE TABLE `bloques` (
  `id` int(11) NOT NULL auto_increment,
  `num_bloques` int(20) NOT NULL,
  `hora_inicio` varchar(10) collate utf8_spanish_ci NOT NULL,
  `hora_fin` varchar(10) collate utf8_spanish_ci NOT NULL,
  `id_dia` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_dia` (`id_dia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `bloques`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `carta_apelacion`
-- 

CREATE TABLE `carta_apelacion` (
  `id` int(11) NOT NULL auto_increment,
  `id_estudiante` int(11) NOT NULL,
  `carta_ap` text collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `iid_estudiante` (`id_estudiante`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `carta_apelacion`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `carta_postulaciones`
-- 

CREATE TABLE `carta_postulaciones` (
  `id` int(11) NOT NULL auto_increment,
  `id_usuario` int(11) NOT NULL,
  `carta_p` text collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `carta_postulaciones`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `catedras`
-- 

CREATE TABLE `catedras` (
  `id` int(11) NOT NULL auto_increment,
  `catedra` varchar(90) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `catedras`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `categorias`
-- 

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL auto_increment,
  `categoria` varchar(30) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `categorias`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `colegio`
-- 

CREATE TABLE `colegio` (
  `id` int(11) NOT NULL auto_increment,
  `tipo_cole` varchar(90) collate utf8_spanish_ci NOT NULL,
  `valor_cole` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `colegio`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `coordinaciones1`
-- 

CREATE TABLE `coordinaciones1` (
  `id` int(11) NOT NULL auto_increment,
  `coordinacion1` varchar(90) collate utf8_spanish_ci NOT NULL,
  `id_area` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_area` (`id_area`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `coordinaciones1`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `coordinaciones1_has_usuarios`
-- 

CREATE TABLE `coordinaciones1_has_usuarios` (
  `id` int(11) NOT NULL auto_increment,
  `id_coordinacion1` int(11) NOT NULL,
  `id_usuarios` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_usuarios` (`id_usuarios`),
  KEY `id_coordinacion1` (`id_coordinacion1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `coordinaciones1_has_usuarios`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `datos_academicos_est`
-- 

CREATE TABLE `datos_academicos_est` (
  `id` int(11) NOT NULL auto_increment,
  `id_estudiante` int(11) NOT NULL,
  `anio_ingreso` int(4) NOT NULL,
  `id_trayecto` int(11) NOT NULL,
  `regimen` varchar(30) collate utf8_spanish_ci NOT NULL,
  `uc` int(3) NOT NULL,
  `uc_apro` int(3) NOT NULL,
  `aprobacion_total` int(3) NOT NULL,
  `condicion` text collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_estudiante` (`id_estudiante`),
  KEY `id_trayecto` (`id_trayecto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `datos_academicos_est`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `depto_coord2`
-- 

CREATE TABLE `depto_coord2` (
  `id` int(11) NOT NULL auto_increment,
  `depto_coord2` varchar(90) collate utf8_spanish_ci NOT NULL,
  `id_coordinacion1` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_coordinacion1` (`id_coordinacion1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `depto_coord2`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `depto_coord2_has_catedras`
-- 

CREATE TABLE `depto_coord2_has_catedras` (
  `id` int(11) NOT NULL auto_increment,
  `id_catedra` int(11) NOT NULL,
  `id_depto_coord2` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_catedra` (`id_catedra`),
  KEY `id_depto_coord2` (`id_depto_coord2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `depto_coord2_has_catedras`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `depto_coord2_has_usuarios`
-- 

CREATE TABLE `depto_coord2_has_usuarios` (
  `id` int(11) NOT NULL auto_increment,
  `id_deptocoord2` int(11) NOT NULL,
  `id_usuarios` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_deptocoord2` (`id_deptocoord2`),
  KEY `id_usuarios` (`id_usuarios`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `depto_coord2_has_usuarios`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `desincorporaciones`
-- 

CREATE TABLE `desincorporaciones` (
  `id` int(11) NOT NULL auto_increment,
  `id_estudiantes` int(11) NOT NULL,
  `id_tipo_desincorporaciones` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_estudiantes` (`id_estudiantes`),
  KEY `id_tipo_desincorporaciones` (`id_tipo_desincorporaciones`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `desincorporaciones`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `dias`
-- 

CREATE TABLE `dias` (
  `id` int(11) NOT NULL auto_increment,
  `dia` varchar(15) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `dias`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `estado_civil`
-- 

CREATE TABLE `estado_civil` (
  `id` int(11) NOT NULL auto_increment,
  `edo_civil` varchar(30) collate utf8_spanish_ci NOT NULL,
  `valor_ec` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `estado_civil`
-- 

INSERT INTO `estado_civil` VALUES (1, 'SOLTERO(A)', 1);
INSERT INTO `estado_civil` VALUES (2, 'CASADO(A)', 2);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `estudiantes`
-- 

CREATE TABLE `estudiantes` (
  `id` int(11) NOT NULL auto_increment,
  `apellido1` varchar(90) collate utf8_spanish_ci NOT NULL,
  `apellido2` varchar(90) collate utf8_spanish_ci NOT NULL,
  `nombre1` varchar(90) collate utf8_spanish_ci NOT NULL,
  `nombre2` varchar(90) collate utf8_spanish_ci NOT NULL,
  `lugar_nac` text collate utf8_spanish_ci NOT NULL,
  `fecha_nac` varchar(30) collate utf8_spanish_ci NOT NULL,
  `nacio` char(1) collate utf8_spanish_ci NOT NULL,
  `cedula` int(8) NOT NULL,
  `sexo` char(1) collate utf8_spanish_ci NOT NULL,
  `id_edocivil` int(11) NOT NULL,
  `condiciones` text collate utf8_spanish_ci NOT NULL,
  `codigo_telf` varchar(4) collate utf8_spanish_ci NOT NULL,
  `telf_cel` varchar(7) collate utf8_spanish_ci NOT NULL,
  `telf_resi` varchar(11) collate utf8_spanish_ci NOT NULL,
  `id_zona` int(11) NOT NULL,
  `direccion` text collate utf8_spanish_ci NOT NULL,
  `av_calle` text collate utf8_spanish_ci NOT NULL,
  `nro_vivienda` int(5) NOT NULL,
  `email` text collate utf8_spanish_ci NOT NULL,
  `facebook` text collate utf8_spanish_ci NOT NULL,
  `twitter` text collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_edocivil` (`id_edocivil`),
  KEY `id_zona` (`id_zona`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `estudiantes`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `estudiantes_bloques`
-- 

CREATE TABLE `estudiantes_bloques` (
  `id` int(11) NOT NULL auto_increment,
  `id_bloque` int(11) NOT NULL,
  `id_dia` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_bloque` (`id_bloque`),
  KEY `id_dia` (`id_dia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `estudiantes_bloques`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `grupo_familiar`
-- 

CREATE TABLE `grupo_familiar` (
  `id` int(11) NOT NULL auto_increment,
  `cantidad_fam` int(2) NOT NULL,
  `valor_fam` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `grupo_familiar`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `grupo_familiar2`
-- 

CREATE TABLE `grupo_familiar2` (
  `id` int(11) NOT NULL auto_increment,
  `apellidos` varchar(30) collate utf8_spanish_ci NOT NULL,
  `nombres` varchar(30) collate utf8_spanish_ci NOT NULL,
  `nacio` char(1) collate utf8_spanish_ci NOT NULL,
  `cedula` int(8) NOT NULL,
  `sexo_gf` char(1) collate utf8_spanish_ci NOT NULL,
  `edad_gf` int(2) NOT NULL,
  `id_parentesco` int(11) NOT NULL,
  `codigo_telf_gf` varchar(4) collate utf8_spanish_ci NOT NULL,
  `telf_cel_gf` varchar(7) collate utf8_spanish_ci NOT NULL,
  `enfermedad` text collate utf8_spanish_ci NOT NULL,
  `reside_fami` text collate utf8_spanish_ci NOT NULL,
  `ocupacion` text collate utf8_spanish_ci NOT NULL,
  `ingreso_mes` int(6) NOT NULL,
  `aporte_mes` int(6) NOT NULL,
  `id_estudiante` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_parentesco` (`id_parentesco`),
  KEY `id_estudiante` (`id_estudiante`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `grupo_familiar2`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `hijos`
-- 

CREATE TABLE `hijos` (
  `id` int(11) NOT NULL auto_increment,
  `cantidad_hijo` int(2) NOT NULL,
  `valor_hijo` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `hijos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `historial`
-- 

CREATE TABLE `historial` (
  `id` int(11) NOT NULL auto_increment,
  `operacion` varchar(30) collate utf8_spanish_ci NOT NULL,
  `fecha` varchar(30) collate utf8_spanish_ci NOT NULL,
  `hora` varchar(10) collate utf8_spanish_ci NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `historial`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `ingreso`
-- 

CREATE TABLE `ingreso` (
  `id` int(11) NOT NULL auto_increment,
  `tipo_ingre` varchar(90) collate utf8_spanish_ci NOT NULL,
  `valor_ingre` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `ingreso`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `inventario`
-- 

CREATE TABLE `inventario` (
  `id` int(11) NOT NULL auto_increment,
  `cantidad_mate` int(10) NOT NULL,
  `stock_minimo` int(10) NOT NULL,
  `id_material` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_material` (`id_material`),
  KEY `id_categoria` (`id_categoria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `inventario`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `lugar`
-- 

CREATE TABLE `lugar` (
  `id` int(11) NOT NULL auto_increment,
  `tipo_lug` varchar(90) collate utf8_spanish_ci NOT NULL,
  `valor_lug` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `lugar`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `material`
-- 

CREATE TABLE `material` (
  `id` int(11) NOT NULL auto_increment,
  `nombre_mate` varchar(30) collate utf8_spanish_ci NOT NULL,
  `id_um` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_um` (`id_um`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `material`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `nivel_anio_escolar`
-- 

CREATE TABLE `nivel_anio_escolar` (
  `id` int(11) NOT NULL auto_increment,
  `tipo_edu` varchar(90) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=7 ;

-- 
-- Volcar la base de datos para la tabla `nivel_anio_escolar`
-- 

INSERT INTO `nivel_anio_escolar` VALUES (1, 'GUARDERÍA');
INSERT INTO `nivel_anio_escolar` VALUES (2, 'PREESCOLAR');
INSERT INTO `nivel_anio_escolar` VALUES (3, 'PRIMARIA');
INSERT INTO `nivel_anio_escolar` VALUES (4, 'SECUNDARIA');
INSERT INTO `nivel_anio_escolar` VALUES (5, 'BACHILLER');
INSERT INTO `nivel_anio_escolar` VALUES (6, 'UNIVERSITARIO');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `parentesco`
-- 

CREATE TABLE `parentesco` (
  `id` int(11) NOT NULL auto_increment,
  `tipo_parent` varchar(15) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=11 ;

-- 
-- Volcar la base de datos para la tabla `parentesco`
-- 

INSERT INTO `parentesco` VALUES (1, 'PADRE');
INSERT INTO `parentesco` VALUES (2, 'MADRE');
INSERT INTO `parentesco` VALUES (3, 'HERMANO(A)');
INSERT INTO `parentesco` VALUES (4, 'ABUELO(A)');
INSERT INTO `parentesco` VALUES (5, 'TIO(A)');
INSERT INTO `parentesco` VALUES (6, 'HIJO(A)');
INSERT INTO `parentesco` VALUES (7, 'SOBRINO(A)');
INSERT INTO `parentesco` VALUES (8, 'PRIMO(A)');
INSERT INTO `parentesco` VALUES (9, 'PADRINO');
INSERT INTO `parentesco` VALUES (10, 'MADRINA');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `profesor`
-- 

CREATE TABLE `profesor` (
  `id` int(11) NOT NULL auto_increment,
  `id_dc_catedra` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_dc_catedra` (`id_dc_catedra`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `profesor`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `resultados`
-- 

CREATE TABLE `resultados` (
  `id` int(11) NOT NULL auto_increment,
  `puntaje` int(2) NOT NULL,
  `strato` varchar(10) collate utf8_spanish_ci NOT NULL,
  `nominacion` varchar(20) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `resultados`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `std_socioeconomico`
-- 

CREATE TABLE `std_socioeconomico` (
  `id` int(11) NOT NULL auto_increment,
  `situacion_socioeco` text collate utf8_spanish_ci NOT NULL,
  `montoasig_mes` float NOT NULL,
  `distribucion_mes` float NOT NULL,
  `id_tipo_vivienda` int(11) NOT NULL,
  `id_tenencia_vivienda` int(11) NOT NULL,
  `id_tae` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_tipo_vivienda` (`id_tipo_vivienda`),
  KEY `id_tenencia_vivienda` (`id_tenencia_vivienda`),
  KEY `id_tae` (`id_tae`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `std_socioeconomico`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tae`
-- 

CREATE TABLE `tae` (
  `id` int(11) NOT NULL auto_increment,
  `tipo_tae` varchar(90) collate utf8_spanish_ci NOT NULL,
  `materia` varchar(90) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `tae`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tenencia_vivienda`
-- 

CREATE TABLE `tenencia_vivienda` (
  `id` int(11) NOT NULL auto_increment,
  `tipo_tenv` varchar(20) collate utf8_spanish_ci NOT NULL,
  `valor_tenv` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=4 ;

-- 
-- Volcar la base de datos para la tabla `tenencia_vivienda`
-- 

INSERT INTO `tenencia_vivienda` VALUES (1, 'PROPIA', 1);
INSERT INTO `tenencia_vivienda` VALUES (2, 'ALQUILADA', 2);
INSERT INTO `tenencia_vivienda` VALUES (3, 'PROPIA CON OPCIÓN A ', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tipo_desincorporaciones`
-- 

CREATE TABLE `tipo_desincorporaciones` (
  `id` int(11) NOT NULL auto_increment,
  `desincorporacion` varchar(90) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `tipo_desincorporaciones`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tipo_solicitud`
-- 

CREATE TABLE `tipo_solicitud` (
  `id` int(11) NOT NULL auto_increment,
  `tipo_solicitud` varchar(90) collate utf8_spanish_ci NOT NULL,
  `estado_sol` varchar(90) collate utf8_spanish_ci NOT NULL,
  `id_estudiantes` int(11) NOT NULL,
  `id_tae` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_estudiante` (`id_estudiantes`),
  KEY `id_tae` (`id_tae`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `tipo_solicitud`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tipo_vivienda`
-- 

CREATE TABLE `tipo_vivienda` (
  `id` int(11) NOT NULL auto_increment,
  `tipo_tv` varchar(20) collate utf8_spanish_ci NOT NULL,
  `valor_tv` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=7 ;

-- 
-- Volcar la base de datos para la tabla `tipo_vivienda`
-- 

INSERT INTO `tipo_vivienda` VALUES (1, 'QUINTA', 1);
INSERT INTO `tipo_vivienda` VALUES (2, 'CASA', 1);
INSERT INTO `tipo_vivienda` VALUES (3, 'APARTAMENTO', 1);
INSERT INTO `tipo_vivienda` VALUES (4, 'ANEXO', 2);
INSERT INTO `tipo_vivienda` VALUES (5, 'HABITACIÓN', 2);
INSERT INTO `tipo_vivienda` VALUES (6, 'OTRO', 2);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `trayecto`
-- 

CREATE TABLE `trayecto` (
  `id` int(11) NOT NULL auto_increment,
  `nivel_trayecto` int(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `trayecto`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `unidad_medida`
-- 

CREATE TABLE `unidad_medida` (
  `id` int(11) NOT NULL auto_increment,
  `nombre_unidad` varchar(30) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `unidad_medida`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuarios`
-- 

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL auto_increment,
  `nombre_u` varchar(30) collate utf8_spanish_ci NOT NULL,
  `nacio_u` varchar(90) collate utf8_spanish_ci NOT NULL,
  `cedula_u` varchar(90) collate utf8_spanish_ci NOT NULL,
  `codigo` varchar(90) collate utf8_spanish_ci NOT NULL,
  `telf` varchar(90) collate utf8_spanish_ci NOT NULL,
  `login` varchar(30) collate utf8_spanish_ci NOT NULL,
  `clave` text collate utf8_spanish_ci NOT NULL,
  `pregunta` text collate utf8_spanish_ci NOT NULL,
  `respuesta` text collate utf8_spanish_ci NOT NULL,
  `tpocuenta` varchar(30) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `usuarios`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuario_iniciado`
-- 

CREATE TABLE `usuario_iniciado` (
  `id` int(11) NOT NULL auto_increment,
  `estados` char(1) collate utf8_spanish_ci NOT NULL,
  `id_usuarios` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_usuarios` (`id_usuarios`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `usuario_iniciado`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `zonas_postales`
-- 

CREATE TABLE `zonas_postales` (
  `id` int(11) NOT NULL auto_increment,
  `estado` varchar(60) collate utf8_spanish_ci NOT NULL,
  `zona` text collate utf8_spanish_ci NOT NULL,
  `codigo` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1351 ;

-- 
-- Volcar la base de datos para la tabla `zonas_postales`
-- 

INSERT INTO `zonas_postales` VALUES (1, 'Aragua', '10 de Diciembre', 2107);
INSERT INTO `zonas_postales` VALUES (2, 'Aragua', '12 de Febrero', 2104);
INSERT INTO `zonas_postales` VALUES (3, 'Aragua', '12 de Octubre (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (4, 'Aragua', '13 de Enero I, II, III (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (5, 'Aragua', '13 de Junio (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (6, 'Aragua', '18 de Mayo (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (7, 'Aragua', '1º de Mayo (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (8, 'Aragua', '23 de Enero (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (9, 'Aragua', '5 de Julio', 2118);
INSERT INTO `zonas_postales` VALUES (10, 'Aragua', '5 de Julio (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (11, 'Aragua', 'Alayón (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (12, 'Aragua', 'Alberto Solano (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (13, 'Aragua', 'Alí Primera (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (14, 'Aragua', 'Andrés Bello (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (15, 'Aragua', 'Andrés Eloy (Santa Cruz)', 2123);
INSERT INTO `zonas_postales` VALUES (16, 'Aragua', 'Andrés Eloy Blanco (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (17, 'Aragua', 'Angélica de Lusinchi (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (18, 'Aragua', 'Apolo (Villa de Cura)', 2126);
INSERT INTO `zonas_postales` VALUES (19, 'Aragua', 'Aquiles Nazoa (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (20, 'Aragua', 'Aragüita (Villa de Cura)', 2126);
INSERT INTO `zonas_postales` VALUES (21, 'Aragua', 'Arias Blanco (El Limón)', 2105);
INSERT INTO `zonas_postales` VALUES (22, 'Aragua', 'Arsenal (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (23, 'Aragua', 'Barrancón (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (24, 'Aragua', 'Barrancón (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (25, 'Aragua', 'Base Aragua (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (26, 'Aragua', 'Bella Vista (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (27, 'Aragua', 'Bella Vista (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (28, 'Aragua', 'Bello Monte (Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (29, 'Aragua', 'Bello Monte I y II (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (30, 'Aragua', 'Bermúdez (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (31, 'Aragua', 'Bolívar (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (32, 'Aragua', 'Bolívar (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (33, 'Aragua', 'Bolívar (San Mateo)', 2120);
INSERT INTO `zonas_postales` VALUES (34, 'Aragua', 'Bosque Lindo (El Consejo)', 2118);
INSERT INTO `zonas_postales` VALUES (35, 'Aragua', 'Brisas del Lago (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (36, 'Aragua', 'Caballero (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (37, 'Aragua', 'Cadillal (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (38, 'Aragua', 'Cagua (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (39, 'Aragua', 'Calicanto (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (40, 'Aragua', 'Camburito (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (41, 'Aragua', 'Camejo (Villa de Cura)', 2126);
INSERT INTO `zonas_postales` VALUES (42, 'Aragua', 'Campo Alegre (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (43, 'Aragua', 'Campo Alegre (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (44, 'Aragua', 'Campo Claro (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (45, 'Aragua', 'Campo Elías (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (46, 'Aragua', 'Cantarrana (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (47, 'Aragua', 'Cantor Nieve Río (Tejerías)', 2119);
INSERT INTO `zonas_postales` VALUES (48, 'Aragua', 'Carlos Andrés Pérez (Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (49, 'Aragua', 'Carlos Maza (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (50, 'Aragua', 'Carrizalito (Villa de Cura)', 2126);
INSERT INTO `zonas_postales` VALUES (51, 'Aragua', 'Carrizalito (Villa de Cura)', 2126);
INSERT INTO `zonas_postales` VALUES (52, 'Aragua', 'Casanova Godoy (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (53, 'Aragua', 'Casco de La Ciudad (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (54, 'Aragua', 'Cata (Ocumare de La Costa)', 2114);
INSERT INTO `zonas_postales` VALUES (55, 'Aragua', 'Caña de Azúcar (Maracay)', 2105);
INSERT INTO `zonas_postales` VALUES (56, 'Aragua', 'Cañaote (Tejerías)', 2119);
INSERT INTO `zonas_postales` VALUES (57, 'Aragua', 'Cementerio (El Consejo)', 2118);
INSERT INTO `zonas_postales` VALUES (58, 'Aragua', 'Choroní (Choroní)', 2110);
INSERT INTO `zonas_postales` VALUES (59, 'Aragua', 'Ciudad Jardín (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (60, 'Aragua', 'Ciudad Jardín (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (61, 'Aragua', 'Ciudad Universitaria (El Limón)', 2105);
INSERT INTO `zonas_postales` VALUES (62, 'Aragua', 'Codazzi (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (63, 'Aragua', 'Colonia Tovar', 1030);
INSERT INTO `zonas_postales` VALUES (64, 'Aragua', 'Cooperativa Los Olivos Nuevos (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (65, 'Aragua', 'Cooperativa Los Olivos Viejos (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (66, 'Aragua', 'Corianza (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (67, 'Aragua', 'Corocito (San Mateo)', 2120);
INSERT INTO `zonas_postales` VALUES (68, 'Aragua', 'Coromoto (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (69, 'Aragua', 'Curiepe (Tejerías)', 2119);
INSERT INTO `zonas_postales` VALUES (70, 'Aragua', 'Cuyagua (Ocumare de La Costa)', 2112);
INSERT INTO `zonas_postales` VALUES (71, 'Aragua', 'Doctor Pedro García (Turmero)', 2116);
INSERT INTO `zonas_postales` VALUES (72, 'Aragua', 'El Bosque (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (73, 'Aragua', 'El Béisbol (Tejerías)', 2119);
INSERT INTO `zonas_postales` VALUES (74, 'Aragua', 'El Carmen (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (75, 'Aragua', 'El Carmen (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (76, 'Aragua', 'El Carmen (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (77, 'Aragua', 'El Cementerio (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (78, 'Aragua', 'El Centro (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (79, 'Aragua', 'El Consejo (El Consejo)', 2118);
INSERT INTO `zonas_postales` VALUES (80, 'Aragua', 'El Esfuerzo (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (81, 'Aragua', 'El Estadium (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (82, 'Aragua', 'El Hipódromo (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (83, 'Aragua', 'El Indio (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (84, 'Aragua', 'El Lago (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (85, 'Aragua', 'El Lechosal (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (86, 'Aragua', 'El Macaro (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (87, 'Aragua', 'El Maomo (Santa Cruz)', 2123);
INSERT INTO `zonas_postales` VALUES (88, 'Aragua', 'El Milagro (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (89, 'Aragua', 'El Nido (El Consejo)', 2118);
INSERT INTO `zonas_postales` VALUES (90, 'Aragua', 'El Ortiseño (Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (91, 'Aragua', 'El Piñal (El Limón, Maracay)', 2105);
INSERT INTO `zonas_postales` VALUES (92, 'Aragua', 'El Progreso (El Limón, Maracay)', 2105);
INSERT INTO `zonas_postales` VALUES (93, 'Aragua', 'El Recreo (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (94, 'Aragua', 'El Recurso (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (95, 'Aragua', 'El Remanso (Santa Cruz)', 2123);
INSERT INTO `zonas_postales` VALUES (96, 'Aragua', 'El Tierral (19 de Abril Maracay)', 2107);
INSERT INTO `zonas_postales` VALUES (97, 'Aragua', 'El Topo (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (98, 'Aragua', 'El Toquito (Villa de Cura)', 2126);
INSERT INTO `zonas_postales` VALUES (99, 'Aragua', 'El Toro (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (100, 'Aragua', 'El Toro (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (101, 'Aragua', 'El Triunfo (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (102, 'Aragua', 'El Trébol (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (103, 'Aragua', 'El Valle de Santa Rita (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (104, 'Aragua', 'El Viñedo (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (105, 'Aragua', 'Ezequiel Zamora Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (106, 'Aragua', 'Francisco de Miranda (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (107, 'Aragua', 'Francisco de Miranda (Villa de Cura)', 2126);
INSERT INTO `zonas_postales` VALUES (108, 'Aragua', 'Funda Villa I y II (Villa de Cura)', 2126);
INSERT INTO `zonas_postales` VALUES (109, 'Aragua', 'Fundación Mendoza (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (110, 'Aragua', 'Girardot (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (111, 'Aragua', 'Guanarito (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (112, 'Aragua', 'Guaracarima (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (113, 'Aragua', 'Guaruto (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (114, 'Aragua', 'Guayabita (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (115, 'Aragua', 'Guayamura (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (116, 'Aragua', 'Guillen (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (117, 'Aragua', 'Güere (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (118, 'Aragua', 'Güerito (19 de Abril, Maracay)', 2107);
INSERT INTO `zonas_postales` VALUES (119, 'Aragua', 'Jabillar (Tejerias)', 2119);
INSERT INTO `zonas_postales` VALUES (120, 'Aragua', 'Jaime II (Villa de Cura)', 2126);
INSERT INTO `zonas_postales` VALUES (121, 'Aragua', 'José Antonio Páez (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (122, 'Aragua', 'José Casanova Godoy (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (123, 'Aragua', 'José Félix Rivas (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (124, 'Aragua', 'José Gregorio Hernández (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (125, 'Aragua', 'Juan Moreno (El Consejo)', 2118);
INSERT INTO `zonas_postales` VALUES (126, 'Aragua', 'Juana Medina (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (127, 'Aragua', 'Julio Bracho (El Consejo)', 2118);
INSERT INTO `zonas_postales` VALUES (128, 'Aragua', 'La Arboleda (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (129, 'Aragua', 'La Arboleda (Santa Cruz)', 2123);
INSERT INTO `zonas_postales` VALUES (130, 'Aragua', 'La Atascoza (Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (131, 'Aragua', 'La Avanzada (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (132, 'Aragua', 'La Barraca (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (133, 'Aragua', 'La Candelaria (El Limón, Maracay)', 2105);
INSERT INTO `zonas_postales` VALUES (134, 'Aragua', 'La Candelaria (Santa Cruz)', 2123);
INSERT INTO `zonas_postales` VALUES (135, 'Aragua', 'La Capillita (Santa Cruz)', 2123);
INSERT INTO `zonas_postales` VALUES (136, 'Aragua', 'La Carpiera (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (137, 'Aragua', 'La Chapa (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (138, 'Aragua', 'La Chatarrera (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (139, 'Aragua', 'La Concepción (El Consejo)', 2118);
INSERT INTO `zonas_postales` VALUES (140, 'Aragua', 'La Crispera (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (141, 'Aragua', 'La Cruz (El Consejo)', 2118);
INSERT INTO `zonas_postales` VALUES (142, 'Aragua', 'La Cruz (El Limón, Maracay)', 2105);
INSERT INTO `zonas_postales` VALUES (143, 'Aragua', 'La Cruz(La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (144, 'Aragua', 'La Cuarta (Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (145, 'Aragua', 'La Curia (San Mateo)', 2120);
INSERT INTO `zonas_postales` VALUES (146, 'Aragua', 'La Democracia (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (147, 'Aragua', 'La Encrucijada (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (148, 'Aragua', 'La Esmeralda (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (149, 'Aragua', 'La Esmeraldita (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (150, 'Aragua', 'La Floresta (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (151, 'Aragua', 'La Frontera (Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (152, 'Aragua', 'La Frontera (Santa Cruz)', 2123);
INSERT INTO `zonas_postales` VALUES (153, 'Aragua', 'La Fuente (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (154, 'Aragua', 'La Fundación (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (155, 'Aragua', 'La Gallera (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (156, 'Aragua', 'La Hacienda (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (157, 'Aragua', 'La Haciendita (Santa Cruz)', 2123);
INSERT INTO `zonas_postales` VALUES (158, 'Aragua', 'La Hamaca (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (159, 'Aragua', 'La Herrereña (19 de Abril, Maracay)', 2107);
INSERT INTO `zonas_postales` VALUES (160, 'Aragua', 'La Iguana (El Consejo)', 2118);
INSERT INTO `zonas_postales` VALUES (161, 'Aragua', 'La Independencia (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (162, 'Aragua', 'La Isabelita (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (163, 'Aragua', 'La Julia (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (164, 'Aragua', 'La Majada (Santa Cruz)', 2123);
INSERT INTO `zonas_postales` VALUES (165, 'Aragua', 'La Maracaya (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (166, 'Aragua', 'La Mora (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (167, 'Aragua', 'La Morita I y III (19 de Abril, Maracay)', 2107);
INSERT INTO `zonas_postales` VALUES (168, 'Aragua', 'La Olla (El Consejo)', 2118);
INSERT INTO `zonas_postales` VALUES (169, 'Aragua', 'La Ovallera (Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (170, 'Aragua', 'La Participación (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (171, 'Aragua', 'La Paz (19 de Abril, Maracay)', 2107);
INSERT INTO `zonas_postales` VALUES (172, 'Aragua', 'La Paz (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (173, 'Aragua', 'La Pedrera (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (174, 'Aragua', 'La Pica (Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (175, 'Aragua', 'La Primavera (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (176, 'Aragua', 'La Providencia (19 de Abril, Maracay)', 2107);
INSERT INTO `zonas_postales` VALUES (177, 'Aragua', 'La Punta (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (178, 'Aragua', 'La Represa (Villa de Cura)', 2126);
INSERT INTO `zonas_postales` VALUES (179, 'Aragua', 'La Rinconada (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (180, 'Aragua', 'La Romana Nueva (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (181, 'Aragua', 'La Romana Vieja (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (182, 'Aragua', 'La Rosa (El Consejo)', 2118);
INSERT INTO `zonas_postales` VALUES (183, 'Aragua', 'La Segundera (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (184, 'Aragua', 'La Soledad (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (185, 'Aragua', 'Las Acacias (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (186, 'Aragua', 'Las Animas I y II (Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (187, 'Aragua', 'Las Brisas (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (188, 'Aragua', 'Las Brisas (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (189, 'Aragua', 'Las Carmenes (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (190, 'Aragua', 'Las Casitas (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (191, 'Aragua', 'Las Cruces (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (192, 'Aragua', 'Las Delicias (Barrio, Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (193, 'Aragua', 'Las Delicias (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (194, 'Aragua', 'Las Delicias (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (195, 'Aragua', 'Las Flores (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (196, 'Aragua', 'Las Flores (San Mateo)', 2120);
INSERT INTO `zonas_postales` VALUES (197, 'Aragua', 'Las Flores (San Mateo)', 2120);
INSERT INTO `zonas_postales` VALUES (198, 'Aragua', 'Las Luisas (El Consejo)', 2118);
INSERT INTO `zonas_postales` VALUES (199, 'Aragua', 'Las Mayas (El Limón, Maracay)', 2105);
INSERT INTO `zonas_postales` VALUES (200, 'Aragua', 'Las Mercedes (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (201, 'Aragua', 'Las Mercedes (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (202, 'Aragua', 'Las Mercedes (Villa de Cura)', 2126);
INSERT INTO `zonas_postales` VALUES (203, 'Aragua', 'Las Peñitas (Villa de Cura)', 2126);
INSERT INTO `zonas_postales` VALUES (204, 'Aragua', 'Las Tunas (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (205, 'Aragua', 'Las Vegas (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (206, 'Aragua', 'Las Vegas I y II (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (207, 'Aragua', 'Libertad (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (208, 'Aragua', 'Libertad (Tejerias)', 2119);
INSERT INTO `zonas_postales` VALUES (209, 'Aragua', 'Libertador (19 de Abril, Palo Negro)', 2107);
INSERT INTO `zonas_postales` VALUES (210, 'Aragua', 'Libertador (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (211, 'Aragua', 'Libertador (Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (212, 'Aragua', 'Los Cachos (Tejerias)', 2119);
INSERT INTO `zonas_postales` VALUES (213, 'Aragua', 'Los Caobos (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (214, 'Aragua', 'Los Caobos (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (215, 'Aragua', 'Los Cerritos (El Consejo)', 2118);
INSERT INTO `zonas_postales` VALUES (216, 'Aragua', 'Los Chaguaramos (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (217, 'Aragua', 'Los Cocos (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (218, 'Aragua', 'Los Cocos (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (219, 'Aragua', 'Los Colorados (Villa de Cura)', 2126);
INSERT INTO `zonas_postales` VALUES (220, 'Aragua', 'Los Galpones (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (221, 'Aragua', 'Los Hornos (Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (222, 'Aragua', 'Los Jabillos (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (223, 'Aragua', 'Los Jabillos (Tejerias)', 2119);
INSERT INTO `zonas_postales` VALUES (224, 'Aragua', 'Los Manguitos (Santa Cruz)', 2123);
INSERT INTO `zonas_postales` VALUES (225, 'Aragua', 'Los Manguitos (Santa Cruz)', 2123);
INSERT INTO `zonas_postales` VALUES (226, 'Aragua', 'Los Naranjos (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (227, 'Aragua', 'Los Naranjos (Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (228, 'Aragua', 'Los Nísperos (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (229, 'Aragua', 'Los Nísperos (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (230, 'Aragua', 'Los Overos (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (231, 'Aragua', 'Los Pinos (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (232, 'Aragua', 'Los Próceres (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (233, 'Aragua', 'Los Rauceos (El Limón, Maracay)', 2105);
INSERT INTO `zonas_postales` VALUES (234, 'Aragua', 'Los Rosales (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (235, 'Aragua', 'Los Samanes (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (236, 'Aragua', 'Los Tanques (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (237, 'Aragua', 'Los Tubos (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (238, 'Aragua', 'Lourdes (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (239, 'Aragua', 'Magdaleno (Magdaleno)', 2128);
INSERT INTO `zonas_postales` VALUES (240, 'Aragua', 'Malariología Antonio Aranguren (Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (241, 'Aragua', 'Maracay II (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (242, 'Aragua', 'Marcelo Guzmán (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (243, 'Aragua', 'Mario Briceño Iragorry (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (244, 'Aragua', 'Mariscal Sucre (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (245, 'Aragua', 'María Cristina (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (246, 'Aragua', 'Mata Redonda (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (247, 'Aragua', 'Mata Redonda (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (248, 'Aragua', 'Mata Seca (El Limón, Maracay)', 2105);
INSERT INTO `zonas_postales` VALUES (249, 'Aragua', 'Medina Angarita (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (250, 'Aragua', 'Mendoza (Tejerias)', 2119);
INSERT INTO `zonas_postales` VALUES (251, 'Aragua', 'Miranda (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (252, 'Aragua', 'Monserrat (Santa Cruz)', 2123);
INSERT INTO `zonas_postales` VALUES (253, 'Aragua', 'Mora 2 (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (254, 'Aragua', 'Morean Soto (19 de Abril, Maracay)', 2107);
INSERT INTO `zonas_postales` VALUES (255, 'Aragua', 'Morian Soto (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (256, 'Aragua', 'Morita II (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (257, 'Aragua', 'Negro Primero (Villa de Cura)', 2126);
INSERT INTO `zonas_postales` VALUES (258, 'Aragua', 'Niño de Jesús (El Consejo)', 2118);
INSERT INTO `zonas_postales` VALUES (259, 'Aragua', 'Niño de Jesús (El Limón, Maracay)', 2105);
INSERT INTO `zonas_postales` VALUES (260, 'Aragua', 'Oasis (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (261, 'Aragua', 'Ocumare de La Costa (Ocumare de La Costa)', 2112);
INSERT INTO `zonas_postales` VALUES (262, 'Aragua', 'Ocumarito (Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (263, 'Aragua', 'Orope (San Mateo)', 2120);
INSERT INTO `zonas_postales` VALUES (264, 'Aragua', 'Palma Real (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (265, 'Aragua', 'Palo Negro (Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (266, 'Aragua', 'Paraparal I, II, III (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (267, 'Aragua', 'Payita (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (268, 'Aragua', 'Peñuela Ruiz (Santa Cruz)', 2123);
INSERT INTO `zonas_postales` VALUES (269, 'Aragua', 'Piñonal (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (270, 'Aragua', 'Piñonal Sur (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (271, 'Aragua', 'Polvorín (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (272, 'Aragua', 'Portachuelo (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (273, 'Aragua', 'Primitivo de Jesús (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (274, 'Aragua', 'Pueblo Nuevo (Tejerias)', 2119);
INSERT INTO `zonas_postales` VALUES (275, 'Aragua', 'Puerto Colombia', 2113);
INSERT INTO `zonas_postales` VALUES (276, 'Aragua', 'Quebrada de Pipe (San Mateo)', 2120);
INSERT INTO `zonas_postales` VALUES (277, 'Aragua', 'Rafael Caldera (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (278, 'Aragua', 'Rafael Urdaneta (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (279, 'Aragua', 'Residencias Coromoto (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (280, 'Aragua', 'Rodríguez Palencia (19 de Abril, Maracay)', 2107);
INSERT INTO `zonas_postales` VALUES (281, 'Aragua', 'Rosario de Paya (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (282, 'Aragua', 'Ruiz (Tejerias)', 2119);
INSERT INTO `zonas_postales` VALUES (283, 'Aragua', 'Río Blanco I y II (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (284, 'Aragua', 'Rómulo Gallegos (Ocumare de La Costa - Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (285, 'Aragua', 'Sabaneta (El Consejo)', 2118);
INSERT INTO `zonas_postales` VALUES (286, 'Aragua', 'Samán de Güere (19 de Abril, Maracay)', 2107);
INSERT INTO `zonas_postales` VALUES (287, 'Aragua', 'San Carlos (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (288, 'Aragua', 'San Carlos (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (289, 'Aragua', 'San Francisco (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (290, 'Aragua', 'San Francisco de Asís (San Francisco de Asís)', 2125);
INSERT INTO `zonas_postales` VALUES (291, 'Aragua', 'San Ignacio (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (292, 'Aragua', 'San Isidro (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (293, 'Aragua', 'San Jacinto (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (294, 'Aragua', 'San Joaquín de Turmero (19 de Abril, Maracay)', 2107);
INSERT INTO `zonas_postales` VALUES (295, 'Aragua', 'San José (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (296, 'Aragua', 'San Luis (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (297, 'Aragua', 'San Mateo (San Mateo)', 2120);
INSERT INTO `zonas_postales` VALUES (298, 'Aragua', 'San Miguel (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (299, 'Aragua', 'San Miguel (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (300, 'Aragua', 'San Miguel (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (301, 'Aragua', 'San Miguel (Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (302, 'Aragua', 'San Pablo (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (303, 'Aragua', 'San Pedro Alejandrino (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (304, 'Aragua', 'San Vicente (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (305, 'Aragua', 'San Vicente I y II (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (306, 'Aragua', 'Santa Ana (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (307, 'Aragua', 'Santa Ana (Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (308, 'Aragua', 'Santa Cruz (Santa Cruz)', 2123);
INSERT INTO `zonas_postales` VALUES (309, 'Aragua', 'Santa Eduvigis (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (310, 'Aragua', 'Santa Elena (Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (311, 'Aragua', 'Santa Rita (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (312, 'Aragua', 'Santa Rosa (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (313, 'Aragua', 'Santa Rosalía (Cagua)', 2122);
INSERT INTO `zonas_postales` VALUES (314, 'Aragua', 'Santa Rosalía (Palo Negro)', 2117);
INSERT INTO `zonas_postales` VALUES (315, 'Aragua', 'Santo Domingo (El Consejo)', 2118);
INSERT INTO `zonas_postales` VALUES (316, 'Aragua', 'Sector E (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (317, 'Aragua', 'Sector El Mijaú (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (318, 'Aragua', 'Sector Jovalito (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (319, 'Aragua', 'Sector La Ceiba (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (320, 'Aragua', 'Sector La Vaquera (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (321, 'Aragua', 'Sector Punta del Monte (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (322, 'Aragua', 'Sector San José (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (323, 'Aragua', 'Sergio Medina (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (324, 'Aragua', 'Simón Bolívar (El Consejo)', 2118);
INSERT INTO `zonas_postales` VALUES (325, 'Aragua', 'Simón Rodríguez (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (326, 'Aragua', 'Soco (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (327, 'Aragua', 'Sorocaima I y II (19 de Abril, Maracay)', 2107);
INSERT INTO `zonas_postales` VALUES (328, 'Aragua', 'Sucre (19 de Abril, Maracay)', 2107);
INSERT INTO `zonas_postales` VALUES (329, 'Aragua', 'Sucre (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (330, 'Aragua', 'Sucre (Maracay)', 2102);
INSERT INTO `zonas_postales` VALUES (331, 'Aragua', 'Surupei (Santa Cruz)', 2123);
INSERT INTO `zonas_postales` VALUES (332, 'Aragua', 'Tamarindo (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (333, 'Aragua', 'Tejerías (Maracay)', 2105);
INSERT INTO `zonas_postales` VALUES (334, 'Aragua', 'Tejerías (Tejerias)', 2119);
INSERT INTO `zonas_postales` VALUES (335, 'Aragua', 'Tierra Amarilla (Tejerias)', 2119);
INSERT INTO `zonas_postales` VALUES (336, 'Aragua', 'Tinapuey I y II (Tejerias)', 2119);
INSERT INTO `zonas_postales` VALUES (337, 'Aragua', 'Tiuna (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (338, 'Aragua', 'Toronjal (Maracay)', 2104);
INSERT INTO `zonas_postales` VALUES (339, 'Aragua', 'Trapiche del Medio (El Consejo)', 2118);
INSERT INTO `zonas_postales` VALUES (340, 'Aragua', 'Tucutunemo', 2126);
INSERT INTO `zonas_postales` VALUES (341, 'Aragua', 'Turagua (Santa Cruz)', 2123);
INSERT INTO `zonas_postales` VALUES (342, 'Aragua', 'Turmero (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (343, 'Aragua', 'Unión (San Mateo)', 2120);
INSERT INTO `zonas_postales` VALUES (344, 'Aragua', 'Valle Fresco (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (345, 'Aragua', 'Valle Lindo I, II (Turmero)', 2115);
INSERT INTO `zonas_postales` VALUES (346, 'Aragua', 'Valle Verde (Maracay)', 2105);
INSERT INTO `zonas_postales` VALUES (347, 'Aragua', 'Victoria (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (348, 'Aragua', 'Villa Zuica', 2123);
INSERT INTO `zonas_postales` VALUES (349, 'Aragua', 'Villa de Cura (Villa de Cura)', 2126);
INSERT INTO `zonas_postales` VALUES (350, 'Aragua', 'Vía Colonia Tovar (La Victoria)', 2121);
INSERT INTO `zonas_postales` VALUES (351, 'Aragua', 'Yarabi', 2122);
INSERT INTO `zonas_postales` VALUES (352, 'Aragua', 'Zamora', 2120);
INSERT INTO `zonas_postales` VALUES (353, 'Aragua', 'Zuata', 2127);
INSERT INTO `zonas_postales` VALUES (354, 'Aragua', 'Barbacoas', 2301);
INSERT INTO `zonas_postales` VALUES (355, 'Aragua', 'Buenos Aires (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (356, 'Aragua', 'Camatagua', 2335);
INSERT INTO `zonas_postales` VALUES (357, 'Aragua', 'Carmen de Cura', 2335);
INSERT INTO `zonas_postales` VALUES (358, 'Aragua', 'Cuyagua', 2112);
INSERT INTO `zonas_postales` VALUES (359, 'Aragua', 'El Pinal (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (360, 'Aragua', 'Guiripa', 2338);
INSERT INTO `zonas_postales` VALUES (361, 'Aragua', 'Independencia (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (362, 'Aragua', 'La Coromoto (maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (363, 'Aragua', 'San Casimiro', 2338);
INSERT INTO `zonas_postales` VALUES (364, 'Aragua', 'San Francisco de Cara', 2335);
INSERT INTO `zonas_postales` VALUES (365, 'Aragua', 'San Sebastian', 2340);
INSERT INTO `zonas_postales` VALUES (366, 'Aragua', 'Taguay', 2335);
INSERT INTO `zonas_postales` VALUES (367, 'Aragua', 'Tapatapa', 2101);
INSERT INTO `zonas_postales` VALUES (368, 'Aragua', 'Urbanización Andrés Bello', 2101);
INSERT INTO `zonas_postales` VALUES (369, 'Aragua', 'Urbanización Base Aragua', 2101);
INSERT INTO `zonas_postales` VALUES (370, 'Aragua', 'Urbanización Bermúdez (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (371, 'Aragua', 'Urbanización Calicanto (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (372, 'Aragua', 'Urbanización Caña de Azucar (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (373, 'Aragua', 'Urbanización El Castaño (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (374, 'Aragua', 'Urbanización El Limón (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (375, 'Aragua', 'Urbanización El Toro (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (376, 'Aragua', 'Urbanización Fundación Mendoza (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (377, 'Aragua', 'Urbanización Guey (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (378, 'Aragua', 'Urbanización José Felix Rivas', 2101);
INSERT INTO `zonas_postales` VALUES (379, 'Aragua', 'Urbanización La Arboleda (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (380, 'Aragua', 'Urbanización La Candelaria (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (381, 'Aragua', 'Urbanización La Floresta (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (382, 'Aragua', 'Urbanización La Rinconada (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (383, 'Aragua', 'Urbanización La Romana (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (384, 'Aragua', 'Urbanización La Soledad (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (385, 'Aragua', 'Urbanización Las Acacias (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (386, 'Aragua', 'Urbanización Los Caobos (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (387, 'Aragua', 'Urbanización Los Naranjos (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (388, 'Aragua', 'Urbanización Maracay (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (389, 'Aragua', 'Urbanización Piñonal (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (390, 'Aragua', 'Urbanización Piñonal Sur (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (391, 'Aragua', 'Urbanización San Isidro (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (392, 'Aragua', 'Urbanización San Jacinto (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (393, 'Aragua', 'Urbanización Santa Fé (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (394, 'Aragua', 'Urbanización Sergio Medina (Maracay)', 2103);
INSERT INTO `zonas_postales` VALUES (395, 'Aragua', 'Urbanización Tiuna (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (396, 'Aragua', 'Valle Morin', 2338);
INSERT INTO `zonas_postales` VALUES (397, 'Aragua', 'Valle Verde (Maracay)', 2101);
INSERT INTO `zonas_postales` VALUES (398, 'Aragua', 'Villa de Cura', 2126);
INSERT INTO `zonas_postales` VALUES (399, 'Aragua', 'Yarabí', 2122);
INSERT INTO `zonas_postales` VALUES (400, 'Aragua', 'Zuata', 2127);
INSERT INTO `zonas_postales` VALUES (401, 'Aragua', 'Otras Poblaciones', 2101);
INSERT INTO `zonas_postales` VALUES (402, 'Guárico', 'Altagracia de Orituco', 2320);
INSERT INTO `zonas_postales` VALUES (403, 'Guárico', 'Barbacoa', 2334);
INSERT INTO `zonas_postales` VALUES (404, 'Guárico', 'Calabozo', 2312);
INSERT INTO `zonas_postales` VALUES (405, 'Guárico', 'Camatagua', 2335);
INSERT INTO `zonas_postales` VALUES (406, 'Guárico', 'Cambural de Cataure', 2301);
INSERT INTO `zonas_postales` VALUES (407, 'Guárico', 'Carmen de Cura', 2311);
INSERT INTO `zonas_postales` VALUES (408, 'Guárico', 'Chaguaramas', 2358);
INSERT INTO `zonas_postales` VALUES (409, 'Guárico', 'Corozopando', 2301);
INSERT INTO `zonas_postales` VALUES (410, 'Guárico', 'Dos Caminos', 2301);
INSERT INTO `zonas_postales` VALUES (411, 'Guárico', 'El Calvario', 2303);
INSERT INTO `zonas_postales` VALUES (412, 'Guárico', 'El Caro de La Negra', 2301);
INSERT INTO `zonas_postales` VALUES (413, 'Guárico', 'El Corozo', 2301);
INSERT INTO `zonas_postales` VALUES (414, 'Guárico', 'El Palito', 2301);
INSERT INTO `zonas_postales` VALUES (415, 'Guárico', 'El Punzón', 2301);
INSERT INTO `zonas_postales` VALUES (416, 'Guárico', 'El Rastro', 2304);
INSERT INTO `zonas_postales` VALUES (417, 'Guárico', 'El Socorro', 2355);
INSERT INTO `zonas_postales` VALUES (418, 'Guárico', 'El Sombrero', 2319);
INSERT INTO `zonas_postales` VALUES (419, 'Guárico', 'Espino', 2301);
INSERT INTO `zonas_postales` VALUES (420, 'Guárico', 'Francisco de Tiznado', 2301);
INSERT INTO `zonas_postales` VALUES (421, 'Guárico', 'Guardatinaja', 2316);
INSERT INTO `zonas_postales` VALUES (422, 'Guárico', 'Guaripa', 2301);
INSERT INTO `zonas_postales` VALUES (423, 'Guárico', 'Ipare de Orituco', 2301);
INSERT INTO `zonas_postales` VALUES (424, 'Guárico', 'La Arboleda', 2301);
INSERT INTO `zonas_postales` VALUES (425, 'Guárico', 'La Esperanza', 2301);
INSERT INTO `zonas_postales` VALUES (426, 'Guárico', 'Las Mercedes del Llano', 2356);
INSERT INTO `zonas_postales` VALUES (427, 'Guárico', 'Las Minas', 2301);
INSERT INTO `zonas_postales` VALUES (428, 'Guárico', 'Lezama', 2301);
INSERT INTO `zonas_postales` VALUES (429, 'Guárico', 'Libertad de Orituco', 2301);
INSERT INTO `zonas_postales` VALUES (430, 'Guárico', 'Mamonal', 2301);
INSERT INTO `zonas_postales` VALUES (431, 'Guárico', 'Ortíz', 2302);
INSERT INTO `zonas_postales` VALUES (432, 'Guárico', 'Parapara de Ortíz', 2301);
INSERT INTO `zonas_postales` VALUES (433, 'Guárico', 'Paso Real de Macaira', 2301);
INSERT INTO `zonas_postales` VALUES (434, 'Guárico', 'Pirital', 2301);
INSERT INTO `zonas_postales` VALUES (435, 'Guárico', 'Roblecito', 2301);
INSERT INTO `zonas_postales` VALUES (436, 'Guárico', 'Sabana Grande de Orituco', 2301);
INSERT INTO `zonas_postales` VALUES (437, 'Guárico', 'San Casimiro', 2338);
INSERT INTO `zonas_postales` VALUES (438, 'Guárico', 'San Francisco de Cara', 2301);
INSERT INTO `zonas_postales` VALUES (439, 'Guárico', 'San Francisco de Macaira', 2301);
INSERT INTO `zonas_postales` VALUES (440, 'Guárico', 'San José de Anare', 2301);
INSERT INTO `zonas_postales` VALUES (441, 'Guárico', 'San José de Guaribe', 2301);
INSERT INTO `zonas_postales` VALUES (442, 'Guárico', 'San José de Tiznados', 2305);
INSERT INTO `zonas_postales` VALUES (443, 'Guárico', 'San Juan de los Morros', 2301);
INSERT INTO `zonas_postales` VALUES (444, 'Guárico', 'San Rafael de Laya', 2301);
INSERT INTO `zonas_postales` VALUES (445, 'Guárico', 'San Rafael de Orituco', 2301);
INSERT INTO `zonas_postales` VALUES (446, 'Guárico', 'San Sebastián', 2340);
INSERT INTO `zonas_postales` VALUES (447, 'Guárico', 'Santa María de Ipire', 2354);
INSERT INTO `zonas_postales` VALUES (448, 'Guárico', 'Taguay', 2301);
INSERT INTO `zonas_postales` VALUES (449, 'Guárico', 'Tucupido', 2301);
INSERT INTO `zonas_postales` VALUES (450, 'Guárico', 'Valle La Pascua', 2350);
INSERT INTO `zonas_postales` VALUES (451, 'Guárico', 'Valle de Morín (Aragua)', 2301);
INSERT INTO `zonas_postales` VALUES (452, 'Guárico', 'Zaraza', 2332);
INSERT INTO `zonas_postales` VALUES (453, 'Guárico', 'Cabruta', 8007);
INSERT INTO `zonas_postales` VALUES (454, 'Guárico', 'Camatagua', 7001);
INSERT INTO `zonas_postales` VALUES (455, 'Guárico', 'Cazorla', 2301);
INSERT INTO `zonas_postales` VALUES (456, 'Guárico', 'Los Pozotes', 2301);
INSERT INTO `zonas_postales` VALUES (457, 'Guárico', 'San Jose Unare', 2351);
INSERT INTO `zonas_postales` VALUES (458, 'Guárico', 'Santa Rita de Manapire', 2301);
INSERT INTO `zonas_postales` VALUES (459, 'Guárico', 'Otras Poblaciones', 2301);
INSERT INTO `zonas_postales` VALUES (460, 'Carabobo', '13 de Septiembre (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (461, 'Carabobo', '19 de Abril (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (462, 'Carabobo', '1º de Mayo', 2006);
INSERT INTO `zonas_postales` VALUES (463, 'Carabobo', '1º de Mayo (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (464, 'Carabobo', '24 Horas (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (465, 'Carabobo', '3 de Mayo', 2003);
INSERT INTO `zonas_postales` VALUES (466, 'Carabobo', '810 (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (467, 'Carabobo', 'Actoto Campesino Mirandita (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (468, 'Carabobo', 'Agua Blanca (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (469, 'Carabobo', 'Alegría (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (470, 'Carabobo', 'Alexander Burgos (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (471, 'Carabobo', 'Altos De Guaparo (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (472, 'Carabobo', 'Ambrosio Plaza (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (473, 'Carabobo', 'América (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (474, 'Carabobo', 'Andrés Bello (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (475, 'Carabobo', 'Antonio José de Sucre Norte, Sur (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (476, 'Carabobo', 'Aquiles Nazoa (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (477, 'Carabobo', 'Armando Celli (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (478, 'Carabobo', 'Atlas (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (479, 'Carabobo', 'Barrera', 2035);
INSERT INTO `zonas_postales` VALUES (480, 'Carabobo', 'Base Naval', 2050);
INSERT INTO `zonas_postales` VALUES (481, 'Carabobo', 'Bejuma', 2040);
INSERT INTO `zonas_postales` VALUES (482, 'Carabobo', 'Bella Vista I, II, III Etapa (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (483, 'Carabobo', 'Bello Monte 1, 2, 3', 2003);
INSERT INTO `zonas_postales` VALUES (484, 'Carabobo', 'Big Low Center', 2003);
INSERT INTO `zonas_postales` VALUES (485, 'Carabobo', 'Boca de Aroa', 2052);
INSERT INTO `zonas_postales` VALUES (486, 'Carabobo', 'Boca de Tocuyo', 2053);
INSERT INTO `zonas_postales` VALUES (487, 'Carabobo', 'Bocaina 1 y 2 (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (488, 'Carabobo', 'Borburata', 2050);
INSERT INTO `zonas_postales` VALUES (489, 'Carabobo', 'Bosque Serino', 2006);
INSERT INTO `zonas_postales` VALUES (490, 'Carabobo', 'Brisas del Sur (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (491, 'Carabobo', 'Brisas del Terminal (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (492, 'Carabobo', 'Bárbula', 2005);
INSERT INTO `zonas_postales` VALUES (493, 'Carabobo', 'Cabriales (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (494, 'Carabobo', 'Camoruco (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (495, 'Carabobo', 'Campo Alegre (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (496, 'Carabobo', 'Campo Solo', 2006);
INSERT INTO `zonas_postales` VALUES (497, 'Carabobo', 'Canaima (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (498, 'Carabobo', 'Canoabo', 2040);
INSERT INTO `zonas_postales` VALUES (499, 'Carabobo', 'Carabobo', 2035);
INSERT INTO `zonas_postales` VALUES (500, 'Carabobo', 'Carabobo (Campo)', 2035);
INSERT INTO `zonas_postales` VALUES (501, 'Carabobo', 'Carmen Norte, Sur (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (502, 'Carabobo', 'Cañaveral (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (503, 'Carabobo', 'Central Tacarigua', 2003);
INSERT INTO `zonas_postales` VALUES (504, 'Carabobo', 'Centro de Valencia (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (505, 'Carabobo', 'Cesar Giro (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (506, 'Carabobo', 'Chaguaramal (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (507, 'Carabobo', 'Chichiriviche', 2054);
INSERT INTO `zonas_postales` VALUES (508, 'Carabobo', 'Chirgua', 2044);
INSERT INTO `zonas_postales` VALUES (509, 'Carabobo', 'Ciudad Jardín Mañongo (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (510, 'Carabobo', 'Colinas de Guataparo (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (511, 'Carabobo', 'Concordia (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (512, 'Carabobo', 'Coromoto (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (513, 'Carabobo', 'Daimer (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (514, 'Carabobo', 'Democracia 1 y 2 (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (515, 'Carabobo', 'Don Bosco (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (516, 'Carabobo', 'El Bosque (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (517, 'Carabobo', 'El Calvario (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (518, 'Carabobo', 'El Cambur', 2050);
INSERT INTO `zonas_postales` VALUES (519, 'Carabobo', 'El Candelero (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (520, 'Carabobo', 'El Combate (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (521, 'Carabobo', 'El Consejo (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (522, 'Carabobo', 'El Morro 1 y 2', 2006);
INSERT INTO `zonas_postales` VALUES (523, 'Carabobo', 'El Pajal (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (524, 'Carabobo', 'El Palito', 2050);
INSERT INTO `zonas_postales` VALUES (525, 'Carabobo', 'El Palotal (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (526, 'Carabobo', 'El Parral (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (527, 'Carabobo', 'El Prado (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (528, 'Carabobo', 'El Prebo I, II, III (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (529, 'Carabobo', 'El Prebol (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (530, 'Carabobo', 'El Recreo (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (531, 'Carabobo', 'El Rincón (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (532, 'Carabobo', 'El Roble', 2003);
INSERT INTO `zonas_postales` VALUES (533, 'Carabobo', 'El Romancero (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (534, 'Carabobo', 'El Socorro (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (535, 'Carabobo', 'El Trigalito (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (536, 'Carabobo', 'El Trompillo', 2010);
INSERT INTO `zonas_postales` VALUES (537, 'Carabobo', 'El Viñedo (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (538, 'Carabobo', 'El triunfo (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (539, 'Carabobo', 'Escalona (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (540, 'Carabobo', 'Escorcha (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (541, 'Carabobo', 'Eutimio Rivas (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (542, 'Carabobo', 'Ezequiel Zamora (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (543, 'Carabobo', 'Federación (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (544, 'Carabobo', 'Finca (Los Taladros) (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (545, 'Carabobo', 'Flor Amarilla', 2003);
INSERT INTO `zonas_postales` VALUES (546, 'Carabobo', 'Flor Amarillo', 2003);
INSERT INTO `zonas_postales` VALUES (547, 'Carabobo', 'Flores (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (548, 'Carabobo', 'Florida Norte y Sur (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (549, 'Carabobo', 'Francisco de Miranda (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (550, 'Carabobo', 'Freddy Franco (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (551, 'Carabobo', 'Goaigoaza', 2050);
INSERT INTO `zonas_postales` VALUES (552, 'Carabobo', 'Guacara', 2015);
INSERT INTO `zonas_postales` VALUES (553, 'Carabobo', 'Guataparo Country Club (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (554, 'Carabobo', 'Güigüe', 2010);
INSERT INTO `zonas_postales` VALUES (555, 'Carabobo', 'Haras los Aguacates (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (556, 'Carabobo', 'Impacto 1 y 2 (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (557, 'Carabobo', 'Industrial Carabobo', 2003);
INSERT INTO `zonas_postales` VALUES (558, 'Carabobo', 'Industrial Castillito', 2003);
INSERT INTO `zonas_postales` VALUES (559, 'Carabobo', 'Industrial La Guacamaya (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (560, 'Carabobo', 'Industrial La Quizanda', 2003);
INSERT INTO `zonas_postales` VALUES (561, 'Carabobo', 'Industrial Municipal Norte', 2003);
INSERT INTO `zonas_postales` VALUES (562, 'Carabobo', 'Isabelita', 2003);
INSERT INTO `zonas_postales` VALUES (563, 'Carabobo', 'José Gregorio Hernández (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (564, 'Carabobo', 'José Regino Peña (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (565, 'Carabobo', 'Kerdel (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (566, 'Carabobo', 'La Arboleada (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (567, 'Carabobo', 'La Blanquera (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (568, 'Carabobo', 'La California (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (569, 'Carabobo', 'La Castellana (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (570, 'Carabobo', 'La Castrera (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (571, 'Carabobo', 'La Entrada', 2005);
INSERT INTO `zonas_postales` VALUES (572, 'Carabobo', 'La Esmeralda', 2006);
INSERT INTO `zonas_postales` VALUES (573, 'Carabobo', 'La Florida (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (574, 'Carabobo', 'La Guacamaya 1ª, 2ª y 3ª Etapa (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (575, 'Carabobo', 'La Isabelica', 2003);
INSERT INTO `zonas_postales` VALUES (576, 'Carabobo', 'La Línea (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (577, 'Carabobo', 'La Maestranza (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (578, 'Carabobo', 'La Manguita (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (579, 'Carabobo', 'La Milagrosa (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (580, 'Carabobo', 'La Planta (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (581, 'Carabobo', 'La Raya (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (582, 'Carabobo', 'La Romana (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (583, 'Carabobo', 'La Romanita (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (584, 'Carabobo', 'La Sorpresa', 2050);
INSERT INTO `zonas_postales` VALUES (585, 'Carabobo', 'La Trigaleña (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (586, 'Carabobo', 'La Unidad (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (587, 'Carabobo', 'La Viña (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (588, 'Carabobo', 'Las Acacias (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (589, 'Carabobo', 'Las Agüitas', 2003);
INSERT INTO `zonas_postales` VALUES (590, 'Carabobo', 'Las Clavellinas (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (591, 'Carabobo', 'Las Lomas (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (592, 'Carabobo', 'Las Quintas', 2005);
INSERT INTO `zonas_postales` VALUES (593, 'Carabobo', 'Las Trincheras', 2005);
INSERT INTO `zonas_postales` VALUES (594, 'Carabobo', 'Libertador (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (595, 'Carabobo', 'Llano Verde (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (596, 'Carabobo', 'Lomas de Funval (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (597, 'Carabobo', 'Lomas del Este (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (598, 'Carabobo', 'Los Alpes (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (599, 'Carabobo', 'Los Arales', 2006);
INSERT INTO `zonas_postales` VALUES (600, 'Carabobo', 'Los Bucares 1, 2', 2003);
INSERT INTO `zonas_postales` VALUES (601, 'Carabobo', 'Los Caimitos (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (602, 'Carabobo', 'Los Caobos (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (603, 'Carabobo', 'Los Cerritos', 2003);
INSERT INTO `zonas_postales` VALUES (604, 'Carabobo', 'Los Colorados (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (605, 'Carabobo', 'Los Criollitos (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (606, 'Carabobo', 'Los Guayos', 2003);
INSERT INTO `zonas_postales` VALUES (607, 'Carabobo', 'Los Harales', 2006);
INSERT INTO `zonas_postales` VALUES (608, 'Carabobo', 'Los Jardines (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (609, 'Carabobo', 'Los Magallanes', 2006);
INSERT INTO `zonas_postales` VALUES (610, 'Carabobo', 'Los Mangos (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (611, 'Carabobo', 'Los Manguitos (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (612, 'Carabobo', 'Los Naranjos (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (613, 'Carabobo', 'Los Nísperos (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (614, 'Carabobo', 'Los Parques (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (615, 'Carabobo', 'Los Pozones (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (616, 'Carabobo', 'Los Sauces (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (617, 'Carabobo', 'Los Taladros (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (618, 'Carabobo', 'Los Viveros (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (619, 'Carabobo', 'Luis Herrera Campins (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (620, 'Carabobo', 'Mañonguito (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (621, 'Carabobo', 'Mendoza 1, 2, 3, 4, 5, 6 y 7 (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (622, 'Carabobo', 'Michelena Norte y Sur', 2001);
INSERT INTO `zonas_postales` VALUES (623, 'Carabobo', 'Miguel Aché (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (624, 'Carabobo', 'Miranda', 2041);
INSERT INTO `zonas_postales` VALUES (625, 'Carabobo', 'Montalban', 2042);
INSERT INTO `zonas_postales` VALUES (626, 'Carabobo', 'Monte Serino', 2006);
INSERT INTO `zonas_postales` VALUES (627, 'Carabobo', 'Monumental (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (628, 'Carabobo', 'Morón', 2051);
INSERT INTO `zonas_postales` VALUES (629, 'Carabobo', 'Máximo Romero (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (630, 'Carabobo', 'Naguanagua', 2005);
INSERT INTO `zonas_postales` VALUES (631, 'Carabobo', 'Padre Alonzo (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (632, 'Carabobo', 'Palma Real (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (633, 'Carabobo', 'Paraparal', 2003);
INSERT INTO `zonas_postales` VALUES (634, 'Carabobo', 'Parque Valencia', 2003);
INSERT INTO `zonas_postales` VALUES (635, 'Carabobo', 'Parque el Trigal', 2001);
INSERT INTO `zonas_postales` VALUES (636, 'Carabobo', 'Paso Real', 2003);
INSERT INTO `zonas_postales` VALUES (637, 'Carabobo', 'Patanemo', 2050);
INSERT INTO `zonas_postales` VALUES (638, 'Carabobo', 'Piedras Negras', 2003);
INSERT INTO `zonas_postales` VALUES (639, 'Carabobo', 'Piedras Pintadas', 2001);
INSERT INTO `zonas_postales` VALUES (640, 'Carabobo', 'Pueblo de Belén', 2039);
INSERT INTO `zonas_postales` VALUES (641, 'Carabobo', 'Pueblo de Maraira', 2017);
INSERT INTO `zonas_postales` VALUES (642, 'Carabobo', 'Pueblo de San Diego', 2006);
INSERT INTO `zonas_postales` VALUES (643, 'Carabobo', 'Puerto Cabello', 2050);
INSERT INTO `zonas_postales` VALUES (644, 'Carabobo', 'Punto Nutria', 2050);
INSERT INTO `zonas_postales` VALUES (645, 'Carabobo', 'Rancho Grande', 2050);
INSERT INTO `zonas_postales` VALUES (646, 'Carabobo', 'Renny Ottolina (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (647, 'Carabobo', 'Ricardo Urriera (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (648, 'Carabobo', 'Rinconcito Mañongo (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (649, 'Carabobo', 'Ritec (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (650, 'Carabobo', 'Rosarito (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (651, 'Carabobo', 'Ruiz Pineda 1, 2 y 3 (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (652, 'Carabobo', 'Sabana Larga (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (653, 'Carabobo', 'San Agustín (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (654, 'Carabobo', 'San Blas 1, 2 (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (655, 'Carabobo', 'San Blas Viejo (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (656, 'Carabobo', 'San Diego', 2006);
INSERT INTO `zonas_postales` VALUES (657, 'Carabobo', 'San Joaquín', 2018);
INSERT INTO `zonas_postales` VALUES (658, 'Carabobo', 'San José de Tarbes (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (659, 'Carabobo', 'San Rafael (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (660, 'Carabobo', 'San Sebastián (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (661, 'Carabobo', 'Santa Ana (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (662, 'Carabobo', 'Santa Cecilia (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (663, 'Carabobo', 'Santa Eduvigis', 2005);
INSERT INTO `zonas_postales` VALUES (664, 'Carabobo', 'Santa Teresa (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (665, 'Carabobo', 'Sesquicentenario (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (666, 'Carabobo', 'Simón Bolívar (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (667, 'Carabobo', 'Taborda', 2050);
INSERT INTO `zonas_postales` VALUES (668, 'Carabobo', 'Terraza de los Nísperos (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (669, 'Carabobo', 'Tocuyito', 2035);
INSERT INTO `zonas_postales` VALUES (670, 'Carabobo', 'Tocuyo de La Costa', 2053);
INSERT INTO `zonas_postales` VALUES (671, 'Carabobo', 'Trigal Norte, Sur, Centro (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (672, 'Carabobo', 'Tucacas', 2055);
INSERT INTO `zonas_postales` VALUES (673, 'Carabobo', 'Unión (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (674, 'Carabobo', 'Urama', 2051);
INSERT INTO `zonas_postales` VALUES (675, 'Carabobo', 'Urbanización Ciudad Alianza', 2016);
INSERT INTO `zonas_postales` VALUES (676, 'Carabobo', 'Urbanización el Morro', 2006);
INSERT INTO `zonas_postales` VALUES (677, 'Carabobo', 'Valle de Aguirre', 2041);
INSERT INTO `zonas_postales` VALUES (678, 'Carabobo', 'Valle de Camoruco (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (679, 'Carabobo', 'Venezuela (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (680, 'Carabobo', 'Victoria (Valencia)', 2001);
INSERT INTO `zonas_postales` VALUES (681, 'Carabobo', 'Vigirima', 2015);
INSERT INTO `zonas_postales` VALUES (682, 'Carabobo', 'Villa Jardín', 2035);
INSERT INTO `zonas_postales` VALUES (683, 'Carabobo', 'Vivienda Popular de los Guayos', 2003);
INSERT INTO `zonas_postales` VALUES (684, 'Carabobo', 'Vivienda Rural los Arales', 2006);
INSERT INTO `zonas_postales` VALUES (685, 'Carabobo', 'Yagua', 2015);
INSERT INTO `zonas_postales` VALUES (686, 'Carabobo', 'Yuma 1 y 2', 2006);
INSERT INTO `zonas_postales` VALUES (687, 'Carabobo', 'Zona Industrial La Isabelica', 2003);
INSERT INTO `zonas_postales` VALUES (688, 'Carabobo', 'Urbanización Alegria', 2001);
INSERT INTO `zonas_postales` VALUES (689, 'Carabobo', 'Urbanización Altos de Guaparo', 2001);
INSERT INTO `zonas_postales` VALUES (690, 'Carabobo', 'Urbanización Camoruco', 2001);
INSERT INTO `zonas_postales` VALUES (691, 'Carabobo', 'Urbanización Campo Alegre', 2001);
INSERT INTO `zonas_postales` VALUES (692, 'Carabobo', 'Urbanización Campo Solo', 2001);
INSERT INTO `zonas_postales` VALUES (693, 'Carabobo', 'Urbanización Carabobo', 2001);
INSERT INTO `zonas_postales` VALUES (694, 'Carabobo', 'Urbsanización Castillito', 2001);
INSERT INTO `zonas_postales` VALUES (695, 'Carabobo', 'Urbanización Ciudad Jardin Mañongo', 2001);
INSERT INTO `zonas_postales` VALUES (696, 'Carabobo', 'Urbanización Colinas de Guataparo', 2001);
INSERT INTO `zonas_postales` VALUES (697, 'Carabobo', 'Urbanización Colon', 2005);
INSERT INTO `zonas_postales` VALUES (698, 'Carabobo', 'Urbanización chaguaramal', 2001);
INSERT INTO `zonas_postales` VALUES (699, 'Carabobo', 'Urbanización Don Bosco', 2001);
INSERT INTO `zonas_postales` VALUES (700, 'Carabobo', 'Urbanización El Bosque', 2001);
INSERT INTO `zonas_postales` VALUES (701, 'Carabobo', 'Urbanización El Morro 1 y 2', 2001);
INSERT INTO `zonas_postales` VALUES (702, 'Carabobo', 'Urbanización El Palotal', 2001);
INSERT INTO `zonas_postales` VALUES (703, 'Carabobo', 'Urbanización El Parral', 2001);
INSERT INTO `zonas_postales` VALUES (704, 'Carabobo', 'Urbanización El Prado', 2001);
INSERT INTO `zonas_postales` VALUES (705, 'Carabobo', 'Urbanización El Prebo I II III', 2001);
INSERT INTO `zonas_postales` VALUES (706, 'Carabobo', 'Urbanización El Prebol', 2001);
INSERT INTO `zonas_postales` VALUES (707, 'Carabobo', 'Urbanización El Recreo', 2001);
INSERT INTO `zonas_postales` VALUES (708, 'Carabobo', 'Urbanización El Trigalito', 2001);
INSERT INTO `zonas_postales` VALUES (709, 'Carabobo', 'Urbanización El Viñedo', 2001);
INSERT INTO `zonas_postales` VALUES (710, 'Carabobo', 'Urbanización Flor Amarillo', 2003);
INSERT INTO `zonas_postales` VALUES (711, 'Carabobo', 'Urbanización Fundación Mendoza', 2001);
INSERT INTO `zonas_postales` VALUES (712, 'Carabobo', 'Urbanización Guatsaparo Country Club', 2001);
INSERT INTO `zonas_postales` VALUES (713, 'Carabobo', 'Urbanización Guayabal', 2001);
INSERT INTO `zonas_postales` VALUES (714, 'Carabobo', 'Urbanización Kerdel', 2001);
INSERT INTO `zonas_postales` VALUES (715, 'Carabobo', 'Urbanización La Arboleda', 2001);
INSERT INTO `zonas_postales` VALUES (716, 'Carabobo', 'Urbanización La Castellana', 2001);
INSERT INTO `zonas_postales` VALUES (717, 'Carabobo', 'Urbanización La Esmeralda', 2001);
INSERT INTO `zonas_postales` VALUES (718, 'Carabobo', 'Urbanización La Guacamaya 1 2 3 Etapa', 2005);
INSERT INTO `zonas_postales` VALUES (719, 'Carabobo', 'Urbanización La Isabelica', 2003);
INSERT INTO `zonas_postales` VALUES (720, 'Carabobo', 'Urbanización La Trigaleña', 2001);
INSERT INTO `zonas_postales` VALUES (721, 'Carabobo', 'Urbanización La Viña', 2001);
INSERT INTO `zonas_postales` VALUES (722, 'Carabobo', 'Urbanización Las Acacias', 2001);
INSERT INTO `zonas_postales` VALUES (723, 'Carabobo', 'Urbanización Las Clavellinas', 2001);
INSERT INTO `zonas_postales` VALUES (724, 'Carabobo', 'Urbanización Las Quintas', 2005);
INSERT INTO `zonas_postales` VALUES (725, 'Carabobo', 'Urbanización Lomas Del Este', 2001);
INSERT INTO `zonas_postales` VALUES (726, 'Carabobo', 'Urbanización Los Arales', 2006);
INSERT INTO `zonas_postales` VALUES (727, 'Carabobo', 'Urbanización Los Bucares 1 y 2', 2003);
INSERT INTO `zonas_postales` VALUES (728, 'Carabobo', 'Urbanización Los Jardines', 2001);
INSERT INTO `zonas_postales` VALUES (729, 'Carabobo', 'Urbanización Los Magallanes', 2006);
INSERT INTO `zonas_postales` VALUES (730, 'Carabobo', 'Urbanización Los Naranjos', 2001);
INSERT INTO `zonas_postales` VALUES (731, 'Carabobo', 'Urbanización Los Nisperos', 2001);
INSERT INTO `zonas_postales` VALUES (732, 'Carabobo', 'Urbanización Los Sauces', 2001);
INSERT INTO `zonas_postales` VALUES (733, 'Carabobo', 'Urbanización Mendoza 1.2.3.4.5.6.y.7', 2001);
INSERT INTO `zonas_postales` VALUES (734, 'Carabobo', 'Urbanización Michelena Norte y Sur', 2001);
INSERT INTO `zonas_postales` VALUES (735, 'Carabobo', 'Urbanización Monte Serino', 2001);
INSERT INTO `zonas_postales` VALUES (736, 'Carabobo', 'Urbanización Nueva Esparta', 2001);
INSERT INTO `zonas_postales` VALUES (737, 'Carabobo', 'Urbanización Paraparal', 2001);
INSERT INTO `zonas_postales` VALUES (738, 'Carabobo', 'Urbanización Parque El Trigal', 2001);
INSERT INTO `zonas_postales` VALUES (739, 'Carabobo', 'Urbanización Parque Valencia', 2001);
INSERT INTO `zonas_postales` VALUES (740, 'Carabobo', 'Urbanización Paso Real', 2001);
INSERT INTO `zonas_postales` VALUES (741, 'Carabobo', 'Urabanización Piedras Pintada', 2001);
INSERT INTO `zonas_postales` VALUES (742, 'Carabobo', 'Urbanizacion Ritec', 2001);
INSERT INTO `zonas_postales` VALUES (743, 'Carabobo', 'Urbanización Terraza De Los Nisperos', 2001);
INSERT INTO `zonas_postales` VALUES (744, 'Carabobo', 'Urbanización Trigal Norte Sur Centro', 2001);
INSERT INTO `zonas_postales` VALUES (745, 'Carabobo', 'Urbanización Valle De Camoruco', 2001);
INSERT INTO `zonas_postales` VALUES (746, 'Carabobo', 'Urdaneta', 2001);
INSERT INTO `zonas_postales` VALUES (747, 'Carabobo', 'Valle De Aguirre', 2001);
INSERT INTO `zonas_postales` VALUES (748, 'Carabobo', 'Victoria', 2001);
INSERT INTO `zonas_postales` VALUES (749, 'Carabobo', 'Vigirima', 2001);
INSERT INTO `zonas_postales` VALUES (750, 'Carabobo', 'Vivienda Popular De Los Guayos', 2001);
INSERT INTO `zonas_postales` VALUES (751, 'Carabobo', 'Yagua', 2001);
INSERT INTO `zonas_postales` VALUES (752, 'Carabobo', 'Yuma 1 y 2', 2006);
INSERT INTO `zonas_postales` VALUES (753, 'Carabobo', 'Zona Industrial La Isabelica', 2003);
INSERT INTO `zonas_postales` VALUES (754, 'Carabobo', 'Otras Poblaciones', 2001);
INSERT INTO `zonas_postales` VALUES (755, 'Miranda', 'Aeropuerto La Carlota (Caracas)', 1064);
INSERT INTO `zonas_postales` VALUES (756, 'Miranda', 'Araira', 1221);
INSERT INTO `zonas_postales` VALUES (757, 'Miranda', 'Barrio El Carmen Minas de Baruta', 1080);
INSERT INTO `zonas_postales` VALUES (758, 'Miranda', 'Barrio El Carmen Petare', 1073);
INSERT INTO `zonas_postales` VALUES (759, 'Miranda', 'Barrio El Manguito Petare', 1073);
INSERT INTO `zonas_postales` VALUES (760, 'Miranda', 'Barrio El Rodeo', 1221);
INSERT INTO `zonas_postales` VALUES (761, 'Miranda', 'Barrio La Cruz Petare', 1073);
INSERT INTO `zonas_postales` VALUES (762, 'Miranda', 'Barrio La Cruz Chacao', 1060);
INSERT INTO `zonas_postales` VALUES (763, 'Miranda', 'Barrio Niño Jesús', 1030);
INSERT INTO `zonas_postales` VALUES (764, 'Miranda', 'Capaya', 1225);
INSERT INTO `zonas_postales` VALUES (765, 'Miranda', 'Carenero', 1231);
INSERT INTO `zonas_postales` VALUES (766, 'Miranda', 'Carrizal', 1203);
INSERT INTO `zonas_postales` VALUES (767, 'Miranda', 'Caucagüa', 1246);
INSERT INTO `zonas_postales` VALUES (768, 'Miranda', 'Charallave', 1210);
INSERT INTO `zonas_postales` VALUES (769, 'Miranda', 'Chirimena', 1231);
INSERT INTO `zonas_postales` VALUES (770, 'Miranda', 'Chuspa', 1166);
INSERT INTO `zonas_postales` VALUES (771, 'Miranda', 'Chuspita', 1246);
INSERT INTO `zonas_postales` VALUES (772, 'Miranda', 'Cupira', 1238);
INSERT INTO `zonas_postales` VALUES (773, 'Miranda', 'Curiepe', 1232);
INSERT INTO `zonas_postales` VALUES (774, 'Miranda', 'Cúa', 1211);
INSERT INTO `zonas_postales` VALUES (775, 'Miranda', 'El Café', 1225);
INSERT INTO `zonas_postales` VALUES (776, 'Miranda', 'El Guapo', 1243);
INSERT INTO `zonas_postales` VALUES (777, 'Miranda', 'El Hatillo (Caracas)', 1083);
INSERT INTO `zonas_postales` VALUES (778, 'Miranda', 'El Marqués', 1071);
INSERT INTO `zonas_postales` VALUES (779, 'Miranda', 'Guarenas', 1220);
INSERT INTO `zonas_postales` VALUES (780, 'Miranda', 'Guatire', 1221);
INSERT INTO `zonas_postales` VALUES (781, 'Miranda', 'Higuerote', 1231);
INSERT INTO `zonas_postales` VALUES (782, 'Miranda', 'La Tahona', 1083);
INSERT INTO `zonas_postales` VALUES (783, 'Miranda', 'Las González', 1228);
INSERT INTO `zonas_postales` VALUES (784, 'Miranda', 'Lomas de la Lagunita', 1083);
INSERT INTO `zonas_postales` VALUES (785, 'Miranda', 'Los Chorros', 1071);
INSERT INTO `zonas_postales` VALUES (786, 'Miranda', 'Los Samanes', 1080);
INSERT INTO `zonas_postales` VALUES (787, 'Miranda', 'Los Teques', 1201);
INSERT INTO `zonas_postales` VALUES (788, 'Miranda', 'Machurucuto', 1245);
INSERT INTO `zonas_postales` VALUES (789, 'Miranda', 'Mamporal', 1228);
INSERT INTO `zonas_postales` VALUES (790, 'Miranda', 'Ocumare del Tuy', 1209);
INSERT INTO `zonas_postales` VALUES (791, 'Miranda', 'Paparo', 1236);
INSERT INTO `zonas_postales` VALUES (792, 'Miranda', 'Paracotos', 1201);
INSERT INTO `zonas_postales` VALUES (793, 'Miranda', 'Petare', 1073);
INSERT INTO `zonas_postales` VALUES (794, 'Miranda', 'Plaza las Américas', 1061);
INSERT INTO `zonas_postales` VALUES (795, 'Miranda', 'Prados del Este', 1080);
INSERT INTO `zonas_postales` VALUES (796, 'Miranda', 'Pueblo Nuevo Mamporal', 1235);
INSERT INTO `zonas_postales` VALUES (797, 'Miranda', 'Río Chico', 1236);
INSERT INTO `zonas_postales` VALUES (798, 'Miranda', 'San Antonio de los Altos', 1204);
INSERT INTO `zonas_postales` VALUES (799, 'Miranda', 'San Blas', 1073);
INSERT INTO `zonas_postales` VALUES (800, 'Miranda', 'San Diego de los Altos', 1204);
INSERT INTO `zonas_postales` VALUES (801, 'Miranda', 'San Fernando del Guapo', 1243);
INSERT INTO `zonas_postales` VALUES (802, 'Miranda', 'San Francisco de Yare', 1212);
INSERT INTO `zonas_postales` VALUES (803, 'Miranda', 'San José de Barlovento', 1235);
INSERT INTO `zonas_postales` VALUES (804, 'Miranda', 'San José de Río Chico', 1235);
INSERT INTO `zonas_postales` VALUES (805, 'Miranda', 'San José de los Altos', 1204);
INSERT INTO `zonas_postales` VALUES (806, 'Miranda', 'San Pedro de los Altos', 1204);
INSERT INTO `zonas_postales` VALUES (807, 'Miranda', 'Santa Lucia', 1214);
INSERT INTO `zonas_postales` VALUES (808, 'Miranda', 'Santa Paula', 1061);
INSERT INTO `zonas_postales` VALUES (809, 'Miranda', 'Santa Rosa de Lima', 1061);
INSERT INTO `zonas_postales` VALUES (810, 'Miranda', 'Santa Teresa del Tuy', 1215);
INSERT INTO `zonas_postales` VALUES (811, 'Miranda', 'Sebucán', 1071);
INSERT INTO `zonas_postales` VALUES (812, 'Miranda', 'Sector La Estancia (Chuao)', 1064);
INSERT INTO `zonas_postales` VALUES (813, 'Miranda', 'Sector Los Naranjos', 1061);
INSERT INTO `zonas_postales` VALUES (814, 'Miranda', 'Simón Bolívar (Ciudad Tablita)', 1030);
INSERT INTO `zonas_postales` VALUES (815, 'Miranda', 'Tacarigua Mamporal', 1228);
INSERT INTO `zonas_postales` VALUES (816, 'Miranda', 'Tacarigua de La Laguna', 1236);
INSERT INTO `zonas_postales` VALUES (817, 'Miranda', 'Tacata', 1211);
INSERT INTO `zonas_postales` VALUES (818, 'Miranda', 'Terrazas de Club Hípico (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (819, 'Miranda', 'U.S.B.', 1086);
INSERT INTO `zonas_postales` VALUES (820, 'Miranda', 'Urbanización La Urbina', 1073);
INSERT INTO `zonas_postales` VALUES (821, 'Miranda', 'Urbanización Altamira (Caracas)', 1060);
INSERT INTO `zonas_postales` VALUES (822, 'Miranda', 'Urbanización Alto Hatillo (Caracas)', 1083);
INSERT INTO `zonas_postales` VALUES (823, 'Miranda', 'Urbanización Alto Prado (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (824, 'Miranda', 'Urbanización Avila (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (825, 'Miranda', 'Urbanización Bello Campo (Caracas)', 1060);
INSERT INTO `zonas_postales` VALUES (826, 'Miranda', 'Urbanización Boleita', 1071);
INSERT INTO `zonas_postales` VALUES (827, 'Miranda', 'Urbanización Boleita Alta', 1071);
INSERT INTO `zonas_postales` VALUES (828, 'Miranda', 'Urbanización California Norte', 1071);
INSERT INTO `zonas_postales` VALUES (829, 'Miranda', 'Urbanización California Sur', 1071);
INSERT INTO `zonas_postales` VALUES (830, 'Miranda', 'Urbanización Campo Alegre', 1060);
INSERT INTO `zonas_postales` VALUES (831, 'Miranda', 'Urbanización Canteras de Miranda', 1073);
INSERT INTO `zonas_postales` VALUES (832, 'Miranda', 'Urbanización Caracas Country Club', 1060);
INSERT INTO `zonas_postales` VALUES (833, 'Miranda', 'Urbanización Caurimare', 1061);
INSERT INTO `zonas_postales` VALUES (834, 'Miranda', 'Urbanización Chacao', 1060);
INSERT INTO `zonas_postales` VALUES (835, 'Miranda', 'Urbanización Chuao', 1061);
INSERT INTO `zonas_postales` VALUES (836, 'Miranda', 'Urbanización Colinas de Baruta', 1080);
INSERT INTO `zonas_postales` VALUES (837, 'Miranda', 'Urbanización Colinas de Bello Monte', 1050);
INSERT INTO `zonas_postales` VALUES (838, 'Miranda', 'Urbanización Colinas de La California', 1071);
INSERT INTO `zonas_postales` VALUES (839, 'Miranda', 'Urbanización Colinas de La Mariposa', 1090);
INSERT INTO `zonas_postales` VALUES (840, 'Miranda', 'Urbanización Colinas de La Trinidad', 1080);
INSERT INTO `zonas_postales` VALUES (841, 'Miranda', 'Urbanización Colinas de Los Ruices', 1071);
INSERT INTO `zonas_postales` VALUES (842, 'Miranda', 'Urbanización Colinas de Turumo', 1073);
INSERT INTO `zonas_postales` VALUES (843, 'Miranda', 'Urbanización Colinas de Valle Arriba', 1080);
INSERT INTO `zonas_postales` VALUES (844, 'Miranda', 'Urbanización Colinas del Tamanaco', 1061);
INSERT INTO `zonas_postales` VALUES (845, 'Miranda', 'Urbanización Cumbres de Curumo', 1080);
INSERT INTO `zonas_postales` VALUES (846, 'Miranda', 'Urbanización Cútira', 1030);
INSERT INTO `zonas_postales` VALUES (847, 'Miranda', 'Urbanización Don Bosco', 1071);
INSERT INTO `zonas_postales` VALUES (848, 'Miranda', 'Urbanización El Cafetal', 1061);
INSERT INTO `zonas_postales` VALUES (849, 'Miranda', 'Urbanización El Dorado', 1073);
INSERT INTO `zonas_postales` VALUES (850, 'Miranda', 'Urbanización El Llanito', 1073);
INSERT INTO `zonas_postales` VALUES (851, 'Miranda', 'Urbanización El Marqués', 1071);
INSERT INTO `zonas_postales` VALUES (852, 'Miranda', 'Urbanización El Pedregal', 1060);
INSERT INTO `zonas_postales` VALUES (853, 'Miranda', 'Urbanización El Peñón', 1080);
INSERT INTO `zonas_postales` VALUES (854, 'Miranda', 'Urbanización El Placer', 1080);
INSERT INTO `zonas_postales` VALUES (855, 'Miranda', 'Urbanización El Placer de María', 1080);
INSERT INTO `zonas_postales` VALUES (856, 'Miranda', 'Urbanización El Prado', 1040);
INSERT INTO `zonas_postales` VALUES (857, 'Miranda', 'Urbanización El Retiro', 1060);
INSERT INTO `zonas_postales` VALUES (858, 'Miranda', 'Urbanización El Rosal', 1060);
INSERT INTO `zonas_postales` VALUES (859, 'Miranda', 'Urbanización La Boyera', 1083);
INSERT INTO `zonas_postales` VALUES (860, 'Miranda', 'Urbanización La Carlota', 1071);
INSERT INTO `zonas_postales` VALUES (861, 'Miranda', 'Urbanización La Castellana', 1060);
INSERT INTO `zonas_postales` VALUES (862, 'Miranda', 'Urbanización La Ciudadela', 1080);
INSERT INTO `zonas_postales` VALUES (863, 'Miranda', 'Urbanización La Cumbre', 1083);
INSERT INTO `zonas_postales` VALUES (864, 'Miranda', 'Urbanización La Esmeralda', 1083);
INSERT INTO `zonas_postales` VALUES (865, 'Miranda', 'Urbanización La Esperanza', 1030);
INSERT INTO `zonas_postales` VALUES (866, 'Miranda', 'Urbanización La Estancia', 1071);
INSERT INTO `zonas_postales` VALUES (867, 'Miranda', 'Urbanización La Floresta', 1060);
INSERT INTO `zonas_postales` VALUES (868, 'Miranda', 'Urbanización La Lagunita Country Club', 1083);
INSERT INTO `zonas_postales` VALUES (869, 'Miranda', 'Urbanización La Mariposa', 1090);
INSERT INTO `zonas_postales` VALUES (870, 'Miranda', 'Urbanización La Trinidad', 1080);
INSERT INTO `zonas_postales` VALUES (871, 'Miranda', 'Urbanización Las Bonitas', 1080);
INSERT INTO `zonas_postales` VALUES (872, 'Miranda', 'Urbanización Las Mercedes', 1060);
INSERT INTO `zonas_postales` VALUES (873, 'Miranda', 'Urbanización Las Minas', 1080);
INSERT INTO `zonas_postales` VALUES (874, 'Miranda', 'Urbanización Las Vegas de Petare', 1073);
INSERT INTO `zonas_postales` VALUES (875, 'Miranda', 'Urbanización Lomas de Las Mercedes', 1061);
INSERT INTO `zonas_postales` VALUES (876, 'Miranda', 'Urbanización Lomas del Club Hípico', 1080);
INSERT INTO `zonas_postales` VALUES (877, 'Miranda', 'Urbanización Los Cortijos de Lourdes', 1071);
INSERT INTO `zonas_postales` VALUES (878, 'Miranda', 'Urbanización Los Dos Caminos', 1071);
INSERT INTO `zonas_postales` VALUES (879, 'Miranda', 'Urbanización Los Naranjos', 1061);
INSERT INTO `zonas_postales` VALUES (880, 'Miranda', 'Urbanización Los Ruices', 1071);
INSERT INTO `zonas_postales` VALUES (881, 'Miranda', 'Urbanización Macaracuay', 1071);
INSERT INTO `zonas_postales` VALUES (882, 'Miranda', 'Urbanización Mampote', 1073);
INSERT INTO `zonas_postales` VALUES (883, 'Miranda', 'Urbanización Mirador del Este', 1073);
INSERT INTO `zonas_postales` VALUES (884, 'Miranda', 'Urbanización Miranda (Petare, Guarenas)', 1073);
INSERT INTO `zonas_postales` VALUES (885, 'Miranda', 'Urbanización Palo Verde', 1073);
INSERT INTO `zonas_postales` VALUES (886, 'Miranda', 'Urbanización Parque Anauco', 1010);
INSERT INTO `zonas_postales` VALUES (887, 'Miranda', 'Urbanización Parque Sebucán', 1071);
INSERT INTO `zonas_postales` VALUES (888, 'Miranda', 'Urbanización Paseo Las Mercedes', 1061);
INSERT INTO `zonas_postales` VALUES (889, 'Miranda', 'Urbanización Paulo VI', 1073);
INSERT INTO `zonas_postales` VALUES (890, 'Miranda', 'Barrio San Blas', 1073);
INSERT INTO `zonas_postales` VALUES (891, 'Miranda', 'Barrio San Miguel Petare', 1073);
INSERT INTO `zonas_postales` VALUES (892, 'Miranda', 'Barrio Unión', 1020);
INSERT INTO `zonas_postales` VALUES (893, 'Miranda', 'Centro Comercial Plaza Las Americas', 1061);
INSERT INTO `zonas_postales` VALUES (894, 'Miranda', 'Urbanización La Urbina', 1073);
INSERT INTO `zonas_postales` VALUES (895, 'Miranda', 'Urbanización Las Américas', 1020);
INSERT INTO `zonas_postales` VALUES (896, 'Miranda', 'Urbanización Los Chorros', 1071);
INSERT INTO `zonas_postales` VALUES (897, 'Miranda', 'Urbanización Prados Del Este', 1080);
INSERT INTO `zonas_postales` VALUES (898, 'Miranda', 'Urbanización Santa Fe Norte y Sur', 1080);
INSERT INTO `zonas_postales` VALUES (899, 'Miranda', 'Urbanización Santa Ines', 1080);
INSERT INTO `zonas_postales` VALUES (900, 'Miranda', 'Urbanización Santa Paula', 1061);
INSERT INTO `zonas_postales` VALUES (901, 'Miranda', 'Urbanización Santa Sofia', 1061);
INSERT INTO `zonas_postales` VALUES (902, 'Miranda', 'Urbanización Sartenejas', 1080);
INSERT INTO `zonas_postales` VALUES (903, 'Miranda', 'Urbanización Sebucan', 1071);
INSERT INTO `zonas_postales` VALUES (904, 'Miranda', 'Urbanización Sector Los Naranjos', 1061);
INSERT INTO `zonas_postales` VALUES (905, 'Miranda', 'Urbanización Sorocaima', 1080);
INSERT INTO `zonas_postales` VALUES (906, 'Miranda', 'Urbanización Terraza Del Club Hipico', 1080);
INSERT INTO `zonas_postales` VALUES (907, 'Miranda', 'Urbanización Terrazas Del Avila', 1073);
INSERT INTO `zonas_postales` VALUES (908, 'Miranda', 'Urbanización Turiamo', 1020);
INSERT INTO `zonas_postales` VALUES (909, 'Miranda', 'Urbanización Turumo', 1073);
INSERT INTO `zonas_postales` VALUES (910, 'Miranda', 'Urbanización Valle Arriba', 1061);
INSERT INTO `zonas_postales` VALUES (911, 'Distrito Capital', 'Antímano (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (912, 'Distrito Capital', 'Aragüita', 1223);
INSERT INTO `zonas_postales` VALUES (913, 'Distrito Capital', 'Barrio 11 de Agosto (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (914, 'Distrito Capital', 'Barrio 12 de Octubre (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (915, 'Distrito Capital', 'Barrio 1º de Noviembre (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (916, 'Distrito Capital', 'Barrio 24 de Julio (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (917, 'Distrito Capital', 'Barrio 29 de Julio (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (918, 'Distrito Capital', 'Barrio 5 de Julio (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (919, 'Distrito Capital', 'Barrio Agricultura (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (920, 'Distrito Capital', 'Barrio Agua Amarilla (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (921, 'Distrito Capital', 'Barrio Aguacatico (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (922, 'Distrito Capital', 'Barrio Aguacaticos (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (923, 'Distrito Capital', 'Barrio Ajuro (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (924, 'Distrito Capital', 'Barrio Alberto Ravell (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (925, 'Distrito Capital', 'Barrio Alcabala (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (926, 'Distrito Capital', 'Barrio Alfredo Rojas (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (927, 'Distrito Capital', 'Barrio Altos de Cútira (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (928, 'Distrito Capital', 'Barrio Altos de Lídice (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (929, 'Distrito Capital', 'Barrio Anauco (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (930, 'Distrito Capital', 'Barrio Andrés Bello (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (931, 'Distrito Capital', 'Barrio Andrés Eloy Blanco (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (932, 'Distrito Capital', 'Barrio Angarita (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (933, 'Distrito Capital', 'Barrio Antonio José de Sucre (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (934, 'Distrito Capital', 'Barrio Atlántico (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (935, 'Distrito Capital', 'Barrio Bambú (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (936, 'Distrito Capital', 'Barrio Boca de Lobo (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (937, 'Distrito Capital', 'Barrio Bosque de la Virgen (Caracas)', 1083);
INSERT INTO `zonas_postales` VALUES (938, 'Distrito Capital', 'Barrio Brisas de Casalta (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (939, 'Distrito Capital', 'Barrio Brisas de Petare (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (940, 'Distrito Capital', 'Barrio Brisas de Propatria (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (941, 'Distrito Capital', 'Barrio Brisas del Paraíso (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (942, 'Distrito Capital', 'Barrio Bruzual (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (943, 'Distrito Capital', 'Barrio Buenos Aires El Paraiso', 1020);
INSERT INTO `zonas_postales` VALUES (944, 'Distrito Capital', 'Barrio Buenos Aires Petare', 1073);
INSERT INTO `zonas_postales` VALUES (945, 'Distrito Capital', 'Barrio Campo Rico (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (946, 'Distrito Capital', 'Barrio Caraballo (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (947, 'Distrito Capital', 'Barrio Carapa (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (948, 'Distrito Capital', 'Barrio Carapita (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (949, 'Distrito Capital', 'Barrio Caucagüita', 1073);
INSERT INTO `zonas_postales` VALUES (950, 'Distrito Capital', 'Barrio Caño Amarillo (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (951, 'Distrito Capital', 'Barrio Centro Italo (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (952, 'Distrito Capital', 'Barrio Cerro Grande (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (953, 'Distrito Capital', 'Barrio Colón (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (954, 'Distrito Capital', 'Barrio Copey (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (955, 'Distrito Capital', 'Barrio Coromoto (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (956, 'Distrito Capital', 'Barrio Corral de Piedra (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (957, 'Distrito Capital', 'Barrio Cortada de Catia (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (958, 'Distrito Capital', 'Barrio Cortijos (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (959, 'Distrito Capital', 'Barrio Cotiza (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (960, 'Distrito Capital', 'Barrio Cristal (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (961, 'Distrito Capital', 'Barrio El Algodonal (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (962, 'Distrito Capital', 'Barrio El Calvario (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (963, 'Distrito Capital', 'Barrio El Campito (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (964, 'Distrito Capital', 'Barrio El Carmen Catia', 1030);
INSERT INTO `zonas_postales` VALUES (965, 'Distrito Capital', 'Barrio El Cerrito (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (966, 'Distrito Capital', 'Barrio El Desvío (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (967, 'Distrito Capital', 'Barrio El Encanto (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (968, 'Distrito Capital', 'Barrio El Esfuerzo (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (969, 'Distrito Capital', 'Barrio El Guarataro (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (970, 'Distrito Capital', 'Barrio El Güire (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (971, 'Distrito Capital', 'Barrio El Mamón (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (972, 'Distrito Capital', 'Barrio El Manguito San Agustin del Sur', 1010);
INSERT INTO `zonas_postales` VALUES (973, 'Distrito Capital', 'Barrio El Matadero (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (974, 'Distrito Capital', 'Barrio El Mirador (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (975, 'Distrito Capital', 'Barrio El Morro (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (976, 'Distrito Capital', 'Barrio El Mosquito (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (977, 'Distrito Capital', 'Barrio El Nazareno (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (978, 'Distrito Capital', 'Barrio El Observatorio (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (979, 'Distrito Capital', 'Barrio El Refugio (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (980, 'Distrito Capital', 'Barrio El Retiro (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (981, 'Distrito Capital', 'Barrio El Sifón (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (982, 'Distrito Capital', 'Barrio El Triángulo El Cementerio', 1040);
INSERT INTO `zonas_postales` VALUES (983, 'Distrito Capital', 'Barrio El Triángulo La Vega', 1020);
INSERT INTO `zonas_postales` VALUES (984, 'Distrito Capital', 'Barrio Fundación Mendoza (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (985, 'Distrito Capital', 'Barrio Fátima I y II (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (986, 'Distrito Capital', 'Barrio Gato Negro (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (987, 'Distrito Capital', 'Barrio Gramoven (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (988, 'Distrito Capital', 'Barrio Guaicaipuro I (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (989, 'Distrito Capital', 'Barrio Guaicaipuro II (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (990, 'Distrito Capital', 'Barrio Guaicoco (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (991, 'Distrito Capital', 'Barrio Guzmán Blanco (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (992, 'Distrito Capital', 'Barrio Hoyada (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (993, 'Distrito Capital', 'Barrio Hoyo de Las Delicias (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (994, 'Distrito Capital', 'Barrio Isaías Medina (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (995, 'Distrito Capital', 'Barrio Jardín (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (996, 'Distrito Capital', 'Barrio José Félix Rivas (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (997, 'Distrito Capital', 'Barrio José Gregorio Hernández (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (998, 'Distrito Capital', 'Barrio Juan XXIII (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (999, 'Distrito Capital', 'Barrio Julián Blanco (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1000, 'Distrito Capital', 'Barrio La Bandera (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1001, 'Distrito Capital', 'Barrio La Barraca (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1002, 'Distrito Capital', 'Barrio La Bombilla (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1003, 'Distrito Capital', 'Barrio La Ceiba (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1004, 'Distrito Capital', 'Barrio La Ceibita (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1005, 'Distrito Capital', 'Barrio La Charneca (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1006, 'Distrito Capital', 'Barrio La Cuesta (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1007, 'Distrito Capital', 'Barrio La Dolorita (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1008, 'Distrito Capital', 'Barrio La Fénix (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1009, 'Distrito Capital', 'Barrio La Lagunita (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1010, 'Distrito Capital', 'Barrio La Libertad (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1011, 'Distrito Capital', 'Barrio La Línea (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1012, 'Distrito Capital', 'Barrio La Mampita (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1013, 'Distrito Capital', 'Barrio La Matanza (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1014, 'Distrito Capital', 'Barrio La Pedrera (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1015, 'Distrito Capital', 'Barrio La Planada (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1016, 'Distrito Capital', 'Barrio La Puma Rosa (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1017, 'Distrito Capital', 'Barrio La Rubia (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1018, 'Distrito Capital', 'Barrio La Silsa (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (1019, 'Distrito Capital', 'Barrio La Trilla (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1020, 'Distrito Capital', 'Barrio La Veguita (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1021, 'Distrito Capital', 'Barrio La Yagüara II (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (1022, 'Distrito Capital', 'Barrio Ladera (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1023, 'Distrito Capital', 'Barrio Larrazabal (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (1024, 'Distrito Capital', 'Barrio Las Adjuntas (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (1025, 'Distrito Capital', 'Barrio Las Luces (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1026, 'Distrito Capital', 'Barrio Las Mayas (Caracas)', 1090);
INSERT INTO `zonas_postales` VALUES (1027, 'Distrito Capital', 'Barrio Las Tapias (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1028, 'Distrito Capital', 'Barrio Las Tunítas (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (1029, 'Distrito Capital', 'Barrio Los Alpes (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1030, 'Distrito Capital', 'Barrio Los Andinos (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1031, 'Distrito Capital', 'Barrio Los Cangilones (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1032, 'Distrito Capital', 'Barrio Los Cujicitos San Jose', 1010);
INSERT INTO `zonas_postales` VALUES (1033, 'Distrito Capital', 'Barrio Los Cujicitos La Vega', 1020);
INSERT INTO `zonas_postales` VALUES (1034, 'Distrito Capital', 'Barrio Los Erasos (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1035, 'Distrito Capital', 'Barrio Los Eucaliptos (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1036, 'Distrito Capital', 'Barrio Los Frailes', 1030);
INSERT INTO `zonas_postales` VALUES (1037, 'Distrito Capital', 'Barrio Los Higitos', 1030);
INSERT INTO `zonas_postales` VALUES (1038, 'Distrito Capital', 'Barrio Los Lanos (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1039, 'Distrito Capital', 'Barrio Los Manolos (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1040, 'Distrito Capital', 'Barrio Los Mecedores (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1041, 'Distrito Capital', 'Barrio Los Paraparos (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1042, 'Distrito Capital', 'Barrio Lídice (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1043, 'Distrito Capital', 'Barrio Maca (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1044, 'Distrito Capital', 'Barrio Mamera (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (1045, 'Distrito Capital', 'Barrio Marín (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1046, 'Distrito Capital', 'Barrio Medina Angarita (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1047, 'Distrito Capital', 'Barrio Mesuca (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1048, 'Distrito Capital', 'Barrio Minas de Baruta (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (1049, 'Distrito Capital', 'Barrio Monseñor Lebrúm (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1050, 'Distrito Capital', 'Barrio Naranjal 1 y 2 (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1051, 'Distrito Capital', 'Barrio Nazareno (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1052, 'Distrito Capital', 'Barrio Negro Primero (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1053, 'Distrito Capital', 'Barrio Nuevo Chapellin (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1054, 'Distrito Capital', 'Barrio Nuevo Mundo (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1055, 'Distrito Capital', 'Barrio Palo Grande (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1056, 'Distrito Capital', 'Barrio Plan de Manzano', 1030);
INSERT INTO `zonas_postales` VALUES (1057, 'Distrito Capital', 'Barrio Ruperto Lugo', 1030);
INSERT INTO `zonas_postales` VALUES (1058, 'Distrito Capital', 'Baruta (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (1059, 'Distrito Capital', 'Bella Vista (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1060, 'Distrito Capital', 'Birongo', 1232);
INSERT INTO `zonas_postales` VALUES (1061, 'Distrito Capital', 'Cafetal (Caracas)', 1061);
INSERT INTO `zonas_postales` VALUES (1062, 'Distrito Capital', 'Candelaria (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1063, 'Distrito Capital', 'Caricuao (Caracas)', 1083);
INSERT INTO `zonas_postales` VALUES (1064, 'Distrito Capital', 'Carmeliatas (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1065, 'Distrito Capital', 'Carpintero (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1066, 'Distrito Capital', 'Centro Comercial Tamanaco (Caracas)', 1064);
INSERT INTO `zonas_postales` VALUES (1067, 'Distrito Capital', 'Centro Médico Docente (Caracas)', 1083);
INSERT INTO `zonas_postales` VALUES (1068, 'Distrito Capital', 'Chichiriviche', 1162);
INSERT INTO `zonas_postales` VALUES (1069, 'Distrito Capital', 'Colonia Mendoza', 1209);
INSERT INTO `zonas_postales` VALUES (1070, 'Distrito Capital', 'Corocito', 1209);
INSERT INTO `zonas_postales` VALUES (1071, 'Distrito Capital', 'El Clavo', 1241);
INSERT INTO `zonas_postales` VALUES (1072, 'Distrito Capital', 'El Polvorín (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1073, 'Distrito Capital', 'El Valle', 1090);
INSERT INTO `zonas_postales` VALUES (1074, 'Distrito Capital', 'La Candelaria (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1075, 'Distrito Capital', 'La Democracia', 1209);
INSERT INTO `zonas_postales` VALUES (1076, 'Distrito Capital', 'La Pastora (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1077, 'Distrito Capital', 'La Vega (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1078, 'Distrito Capital', 'Las Casitas (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1079, 'Distrito Capital', 'Llanos de Miquillen', 1201);
INSERT INTO `zonas_postales` VALUES (1080, 'Distrito Capital', 'Loma del Aguila (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (1081, 'Distrito Capital', 'Lomas de Terrabel (Caracas)', 1083);
INSERT INTO `zonas_postales` VALUES (1082, 'Distrito Capital', 'Los Magallanes', 1030);
INSERT INTO `zonas_postales` VALUES (1083, 'Distrito Capital', 'Macarao (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (1084, 'Distrito Capital', 'Merecure', 1241);
INSERT INTO `zonas_postales` VALUES (1085, 'Distrito Capital', 'Panaquire', 1226);
INSERT INTO `zonas_postales` VALUES (1086, 'Distrito Capital', 'Paraíso (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1087, 'Distrito Capital', 'Parroquia Altagracia (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1088, 'Distrito Capital', 'Parroquia Catedral (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1089, 'Distrito Capital', 'Parroquia Santa Teresa (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1090, 'Distrito Capital', 'Piedra Azul (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (1091, 'Distrito Capital', 'Piedras Pintadas (Caracas)', 1083);
INSERT INTO `zonas_postales` VALUES (1092, 'Distrito Capital', 'Pinto Salinas (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1093, 'Distrito Capital', 'Plaza Venezuela (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1094, 'Distrito Capital', 'Potrerito (Caracas)', 1090);
INSERT INTO `zonas_postales` VALUES (1095, 'Distrito Capital', 'Prado de María (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1096, 'Distrito Capital', 'Primero de Mayo (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1097, 'Distrito Capital', 'Propatria', 1030);
INSERT INTO `zonas_postales` VALUES (1098, 'Distrito Capital', 'Providencia (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1099, 'Distrito Capital', 'Puerta de Caracas (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1100, 'Distrito Capital', 'Pérez Bonalde (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (1101, 'Distrito Capital', 'Párate Bueno (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (1102, 'Distrito Capital', 'Quebrada Honda (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1103, 'Distrito Capital', 'Quinta Crespo (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1104, 'Distrito Capital', 'Quiripital', 1209);
INSERT INTO `zonas_postales` VALUES (1105, 'Distrito Capital', 'Ruiz Pineda (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (1106, 'Distrito Capital', 'Sabana Grande (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1107, 'Distrito Capital', 'Sabana de Blanco', 1010);
INSERT INTO `zonas_postales` VALUES (1108, 'Distrito Capital', 'San Agustín del Norte (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1109, 'Distrito Capital', 'San Agustín del Sur (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1110, 'Distrito Capital', 'San Andrés (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1111, 'Distrito Capital', 'San Antonio(Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1112, 'Distrito Capital', 'San Antonio (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1113, 'Distrito Capital', 'San Antonio Landér', 1215);
INSERT INTO `zonas_postales` VALUES (1114, 'Distrito Capital', 'San Bernardino (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1115, 'Distrito Capital', 'San José (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1116, 'Distrito Capital', 'San José del Avila (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1117, 'Distrito Capital', 'San Luis (Caracas)', 1061);
INSERT INTO `zonas_postales` VALUES (1118, 'Distrito Capital', 'San Marino (Caracas)', 1060);
INSERT INTO `zonas_postales` VALUES (1119, 'Distrito Capital', 'San Martín (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1120, 'Distrito Capital', 'San Michele (Caracas)', 1071);
INSERT INTO `zonas_postales` VALUES (1121, 'Distrito Capital', 'San Miguel (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1122, 'Distrito Capital', 'San Miguel (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1123, 'Distrito Capital', 'San Miguel (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1124, 'Distrito Capital', 'San Pascual (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1125, 'Distrito Capital', 'San Rafael o Sucre (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1126, 'Distrito Capital', 'San Román (Caracas)', 1061);
INSERT INTO `zonas_postales` VALUES (1127, 'Distrito Capital', 'Sans Souci (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1128, 'Distrito Capital', 'Santa Ana (Caracas)', 1061);
INSERT INTO `zonas_postales` VALUES (1129, 'Distrito Capital', 'Santa Barbara', 1243);
INSERT INTO `zonas_postales` VALUES (1130, 'Distrito Capital', 'Santa Cecilia (Caracas)', 1071);
INSERT INTO `zonas_postales` VALUES (1131, 'Distrito Capital', 'Santa Clara (Caracas)', 1061);
INSERT INTO `zonas_postales` VALUES (1132, 'Distrito Capital', 'Santa Eduvigis (Caracas)', 1071);
INSERT INTO `zonas_postales` VALUES (1133, 'Distrito Capital', 'Santa Fe (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (1134, 'Distrito Capital', 'Santa Gertrudis', 1080);
INSERT INTO `zonas_postales` VALUES (1135, 'Distrito Capital', 'Santa Inés (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (1136, 'Distrito Capital', 'Santa Marta (Caracas)', 1061);
INSERT INTO `zonas_postales` VALUES (1137, 'Distrito Capital', 'Santa María (Caracas)', 1071);
INSERT INTO `zonas_postales` VALUES (1138, 'Distrito Capital', 'Santa Mónica (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1139, 'Distrito Capital', 'Santa Rosa (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1140, 'Distrito Capital', 'Santa Sofía (Caracas)', 1061);
INSERT INTO `zonas_postales` VALUES (1141, 'Distrito Capital', 'Sarría (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1142, 'Distrito Capital', 'Sartenejas (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (1143, 'Distrito Capital', 'Simón Rodríguez (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1144, 'Distrito Capital', 'Solares del Carmen (Caracas)', 1083);
INSERT INTO `zonas_postales` VALUES (1145, 'Distrito Capital', 'Sorocaima (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (1146, 'Distrito Capital', 'Taguao', 1162);
INSERT INTO `zonas_postales` VALUES (1147, 'Distrito Capital', 'Tapipa', 1224);
INSERT INTO `zonas_postales` VALUES (1148, 'Distrito Capital', 'Terrazas de Carapita (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (1149, 'Distrito Capital', 'Terrazas de Caricuao (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (1150, 'Distrito Capital', 'Turiamo (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1151, 'Distrito Capital', 'U.C.V. (Caracas)', 1053);
INSERT INTO `zonas_postales` VALUES (1152, 'Distrito Capital', 'Unidos (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (1153, 'Distrito Capital', 'Unión (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1154, 'Distrito Capital', 'Urbanización Las Américas (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1155, 'Distrito Capital', 'Urbanización La Colina (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1156, 'Distrito Capital', 'Urbanización Los Molinos (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1157, 'Distrito Capital', 'Urbanización (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1158, 'Distrito Capital', 'Urbanización 23 de Enero (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (1159, 'Distrito Capital', 'Urbanización Alberto Ravell (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1160, 'Distrito Capital', 'Urbanización Alegría (Caracas)', 1071);
INSERT INTO `zonas_postales` VALUES (1161, 'Distrito Capital', 'Urbanización Alta Florida (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1162, 'Distrito Capital', 'Urbanización Alta Vista (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (1163, 'Distrito Capital', 'Urbanización Artígas (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1164, 'Distrito Capital', 'Urbanización Arvelo (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1165, 'Distrito Capital', 'Urbanización Bella Vista (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1166, 'Distrito Capital', 'Urbanización Bello Monte (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1167, 'Distrito Capital', 'Urbanización Bicentenario (Caracas)', 1090);
INSERT INTO `zonas_postales` VALUES (1168, 'Distrito Capital', 'Urbanización Bolívar (Caracas)', 1060);
INSERT INTO `zonas_postales` VALUES (1169, 'Distrito Capital', 'Urbanización Buen Pastor (Caracas)', 1071);
INSERT INTO `zonas_postales` VALUES (1170, 'Distrito Capital', 'Urbanización Buena Vista (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1171, 'Distrito Capital', 'Urbanización Campo Claro (Caracas)', 1071);
INSERT INTO `zonas_postales` VALUES (1172, 'Distrito Capital', 'Urbanización Cantarrana (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (1173, 'Distrito Capital', 'Urbanización Caricuao (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (1174, 'Distrito Capital', 'Urbanización Casalta II (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (1175, 'Distrito Capital', 'Urbanización Casalta III (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (1176, 'Distrito Capital', 'Urbanización Catia (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (1177, 'Distrito Capital', 'Urbanización Cañada de La Iglesia (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (1178, 'Distrito Capital', 'Urbanización Cementerio (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1179, 'Distrito Capital', 'Urbanización Chacaito (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1180, 'Distrito Capital', 'Urbanización Chapellín', 1050);
INSERT INTO `zonas_postales` VALUES (1181, 'Distrito Capital', 'Urbanización Charallavito (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (1182, 'Distrito Capital', 'Urbanización Ciudad Industrial Catia (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (1183, 'Distrito Capital', 'Urbanización Coche (Caracas)', 1090);
INSERT INTO `zonas_postales` VALUES (1184, 'Distrito Capital', 'Urbanización Cochecito (Caracas)', 1090);
INSERT INTO `zonas_postales` VALUES (1185, 'Distrito Capital', 'Urbanización Colinas de Bella Vista (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1186, 'Distrito Capital', 'Urbanización Colinas de Coche (Caracas)', 1090);
INSERT INTO `zonas_postales` VALUES (1187, 'Distrito Capital', 'Urbanización Colinas de Las Acacias (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1188, 'Distrito Capital', 'Urbanización Colinas de Los Caobos (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1189, 'Distrito Capital', 'Urbanización Colinas de Los Chaguaramos (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1190, 'Distrito Capital', 'Urbanización Colinas de Santa Mónica (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1191, 'Distrito Capital', 'Urbanización Colinas de Vista Alegre (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1192, 'Distrito Capital', 'Urbanización Continente (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (1193, 'Distrito Capital', 'Urbanización Coracrevi (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (1194, 'Distrito Capital', 'Urbanización Cortijos de Sarría (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1195, 'Distrito Capital', 'Urbanización Cristóbal Rojas (Caracas)', 1090);
INSERT INTO `zonas_postales` VALUES (1196, 'Distrito Capital', 'Urbanización Delgado Chalbaud (Caracas)', 1090);
INSERT INTO `zonas_postales` VALUES (1197, 'Distrito Capital', 'Urbanización Diego de Lozada (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1198, 'Distrito Capital', 'Urbanización El Amparo (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (1199, 'Distrito Capital', 'Urbanización El Bosque', 1050);
INSERT INTO `zonas_postales` VALUES (1200, 'Distrito Capital', 'Urbanización El Bosque (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1201, 'Distrito Capital', 'Urbanización El Conde (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1202, 'Distrito Capital', 'Urbanización El Estadio (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1203, 'Distrito Capital', 'Urbanización El Manicomio', 1030);
INSERT INTO `zonas_postales` VALUES (1204, 'Distrito Capital', 'Urbanización El Paraíso (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1205, 'Distrito Capital', 'Urbanización El Parque (Caracas)', 1071);
INSERT INTO `zonas_postales` VALUES (1206, 'Distrito Capital', 'Urbanización El Pinar (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1207, 'Distrito Capital', 'Urbanización El Rosario (Caracas)', 1071);
INSERT INTO `zonas_postales` VALUES (1208, 'Distrito Capital', 'Urbanización El Silencio (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1209, 'Distrito Capital', 'Urbanización El Topito (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1210, 'Distrito Capital', 'Urbanización Gran Colombia (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1211, 'Distrito Capital', 'Urbanización Guaicaipuro (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1212, 'Distrito Capital', 'Urbanización Guaicay (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (1213, 'Distrito Capital', 'Urbanización Hijos de Dios (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1214, 'Distrito Capital', 'Urbanización Hipódromo (Caracas)', 1090);
INSERT INTO `zonas_postales` VALUES (1215, 'Distrito Capital', 'Urbanización Horizonte (Caracas)', 1071);
INSERT INTO `zonas_postales` VALUES (1216, 'Distrito Capital', 'Urbanización Hornos de Cal (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1217, 'Distrito Capital', 'Urbanización Industrial (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (1218, 'Distrito Capital', 'Urbanización Industrial Carapa (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (1219, 'Distrito Capital', 'Urbanización Industrial La Yaguara (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1220, 'Distrito Capital', 'Urbanización Industrial San Martín (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1221, 'Distrito Capital', 'Urbanización Kennedy (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (1222, 'Distrito Capital', 'Urbanización La Campiña (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1223, 'Distrito Capital', 'Urbanización La Florida (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1224, 'Distrito Capital', 'Urbanización La Hacienda (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (1225, 'Distrito Capital', 'Urbanización La Haciendita (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (1226, 'Distrito Capital', 'Urbanización La Montaña (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1227, 'Distrito Capital', 'Urbanización La Palmita (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1228, 'Distrito Capital', 'Urbanización La Paz (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1229, 'Distrito Capital', 'Urbanización La Quebradita (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1230, 'Distrito Capital', 'Urbanización La Rinconada (Caracas)', 1090);
INSERT INTO `zonas_postales` VALUES (1231, 'Distrito Capital', 'Urbanización La Unión (Caracas)', 1083);
INSERT INTO `zonas_postales` VALUES (1232, 'Distrito Capital', 'Urbanización La Vizcaya (Caracas)', 1061);
INSERT INTO `zonas_postales` VALUES (1233, 'Distrito Capital', 'Urbanización Las Delicias (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1234, 'Distrito Capital', 'Urbanización Las Dos Rosas (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1235, 'Distrito Capital', 'Urbanización Las Flores de Puente Hierro (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1236, 'Distrito Capital', 'Urbanización Las Fuentes (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1237, 'Distrito Capital', 'Urbanización Las Lomas (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (1238, 'Distrito Capital', 'Urbanización Las Lomas de La Florida (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1239, 'Distrito Capital', 'Urbanización Las Lomas de San Rafael (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1240, 'Distrito Capital', 'Urbanización Las Lomitas (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1241, 'Distrito Capital', 'Urbanización Las Marías (Caracas)', 1083);
INSERT INTO `zonas_postales` VALUES (1242, 'Distrito Capital', 'Urbanización Las Mesetas (Caracas)', 1061);
INSERT INTO `zonas_postales` VALUES (1243, 'Distrito Capital', 'Urbanización Las Palmas (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1244, 'Distrito Capital', 'Urbanización Loira (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1245, 'Distrito Capital', 'Urbanización Lomas de Propatria (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (1246, 'Distrito Capital', 'Urbanización Lomas de San Román (Caracas)', 1061);
INSERT INTO `zonas_postales` VALUES (1247, 'Distrito Capital', 'Urbanización Lomas de Santa Marta (Caracas)', 1061);
INSERT INTO `zonas_postales` VALUES (1248, 'Distrito Capital', 'Urbanización Lomas de Urdaneta', 1030);
INSERT INTO `zonas_postales` VALUES (1249, 'Distrito Capital', 'Urbanización Lomas del Mirador (Caracas)', 1061);
INSERT INTO `zonas_postales` VALUES (1250, 'Distrito Capital', 'Urbanización Longaray (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1251, 'Distrito Capital', 'Urbanización Los Campitos (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (1252, 'Distrito Capital', 'Urbanización Los Caobos (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1253, 'Distrito Capital', 'Urbanización Los Carmenes (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1254, 'Distrito Capital', 'Urbanización Los Castaños (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1255, 'Distrito Capital', 'Urbanización Los Cedros (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1256, 'Distrito Capital', 'Urbanización Los Chaguaramos (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1257, 'Distrito Capital', 'Urbanización Los Geranios (Caracas)', 1083);
INSERT INTO `zonas_postales` VALUES (1258, 'Distrito Capital', 'Urbanización Los Guayabitos (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (1259, 'Distrito Capital', 'Urbanización Los Laureles (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1260, 'Distrito Capital', 'Urbanización Los Mangos (La Florida, Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1261, 'Distrito Capital', 'Urbanización Los Mangos (San Martín, Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1262, 'Distrito Capital', 'Urbanización Los Palos Grandes (Caracas)', 1060);
INSERT INTO `zonas_postales` VALUES (1263, 'Distrito Capital', 'Urbanización Los Pomelos (Caracas)', 1061);
INSERT INTO `zonas_postales` VALUES (1264, 'Distrito Capital', 'Urbanización Los Rosales (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1265, 'Distrito Capital', 'Urbanización Luis Hurtado', 1030);
INSERT INTO `zonas_postales` VALUES (1266, 'Distrito Capital', 'Urbanización Mariperez (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1267, 'Distrito Capital', 'Urbanización Miranda (Casalta, Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (1268, 'Distrito Capital', 'Urbanización Mis Encantos (Caracas)', 1060);
INSERT INTO `zonas_postales` VALUES (1269, 'Distrito Capital', 'Urbanización Montalban (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1270, 'Distrito Capital', 'Urbanización Monte Cristo (Caracas)', 1071);
INSERT INTO `zonas_postales` VALUES (1271, 'Distrito Capital', 'Urbanización Monte Elena (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (1272, 'Distrito Capital', 'Urbanización Monte Piedad', 1030);
INSERT INTO `zonas_postales` VALUES (1273, 'Distrito Capital', 'Urbanización Monte Piedad (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (1274, 'Distrito Capital', 'Urbanización Monterrey (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (1275, 'Distrito Capital', 'Urbanización Nueva Caracas (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (1276, 'Distrito Capital', 'Urbanización Nueva Granada', 1040);
INSERT INTO `zonas_postales` VALUES (1277, 'Distrito Capital', 'Urbanización Oritopo (Caracas)', 1083);
INSERT INTO `zonas_postales` VALUES (1278, 'Distrito Capital', 'Urbanización Parque Avila (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1279, 'Distrito Capital', 'Urbanización Parque Carabobo (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1280, 'Distrito Capital', 'Urbanización Parque Central (Caracas)', 1010);
INSERT INTO `zonas_postales` VALUES (1281, 'Distrito Capital', 'Urbanización Parque Humboldt (Caracas)', 1080);
INSERT INTO `zonas_postales` VALUES (1282, 'Distrito Capital', 'Urbanización Pedro Camejo (Caracas)', 1050);
INSERT INTO `zonas_postales` VALUES (1283, 'Distrito Capital', 'Urbanización los flores de Catia', 1030);
INSERT INTO `zonas_postales` VALUES (1284, 'Distrito Capital', 'Urdaneta (Caracas)', 1030);
INSERT INTO `zonas_postales` VALUES (1285, 'Distrito Capital', 'Valle Abajo (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1286, 'Distrito Capital', 'Valle Alto (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1287, 'Distrito Capital', 'Valle Arriba (Caracas)', 1061);
INSERT INTO `zonas_postales` VALUES (1288, 'Distrito Capital', 'Valle Fresco (Caracas)', 1073);
INSERT INTO `zonas_postales` VALUES (1289, 'Distrito Capital', 'Valmore Rodriguez (Caracas)', 1083);
INSERT INTO `zonas_postales` VALUES (1290, 'Distrito Capital', 'Valmore Rodríguez (Caracas)', 1000);
INSERT INTO `zonas_postales` VALUES (1291, 'Distrito Capital', 'Villa Croacia', 1162);
INSERT INTO `zonas_postales` VALUES (1292, 'Distrito Capital', 'Villa Zoila (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1293, 'Distrito Capital', 'Vista Alegre (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1294, 'Distrito Capital', 'Washington (Caracas)', 1020);
INSERT INTO `zonas_postales` VALUES (1295, 'Distrito Capital', 'Zamora (Caracas)', 1040);
INSERT INTO `zonas_postales` VALUES (1296, 'Distrito Capital', 'Barrio Parate Bueno', 1000);
INSERT INTO `zonas_postales` VALUES (1297, 'Distrito Capital', 'Barrio Providencia', 1040);
INSERT INTO `zonas_postales` VALUES (1298, 'Distrito Capital', 'Barrio Puerta de Caracas', 1010);
INSERT INTO `zonas_postales` VALUES (1299, 'Distrito Capital', 'Barrio Quebrada Honda', 1050);
INSERT INTO `zonas_postales` VALUES (1300, 'Distrito Capital', 'Barrio Sabana Del Blanco', 1010);
INSERT INTO `zonas_postales` VALUES (1301, 'Distrito Capital', 'Barrio San Andrés', 1040);
INSERT INTO `zonas_postales` VALUES (1302, 'Distrito Capital', 'Barrio San Miguel Cota 905', 1020);
INSERT INTO `zonas_postales` VALUES (1303, 'Distrito Capital', 'Barrio San Pascual', 1073);
INSERT INTO `zonas_postales` VALUES (1304, 'Distrito Capital', 'Barrio San Rafael o Sucre', 1020);
INSERT INTO `zonas_postales` VALUES (1305, 'Distrito Capital', 'Barrio Simon Bolívar', 1030);
INSERT INTO `zonas_postales` VALUES (1306, 'Distrito Capital', 'Barrio Unidos', 1000);
INSERT INTO `zonas_postales` VALUES (1307, 'Distrito Capital', 'Barrio Valle Fresco', 1073);
INSERT INTO `zonas_postales` VALUES (1308, 'Distrito Capital', 'Barrio Zamora', 1040);
INSERT INTO `zonas_postales` VALUES (1309, 'Distrito Capital', 'Urbanización Las Lomas', 1080);
INSERT INTO `zonas_postales` VALUES (1310, 'Distrito Capital', 'Urbanización Perez Bonalde', 1030);
INSERT INTO `zonas_postales` VALUES (1311, 'Distrito Capital', 'Urbanización Piedra Azul', 1080);
INSERT INTO `zonas_postales` VALUES (1312, 'Distrito Capital', 'Urbanización Pinto Salinas', 1050);
INSERT INTO `zonas_postales` VALUES (1313, 'Distrito Capital', 'Urbanización Potrerito', 1090);
INSERT INTO `zonas_postales` VALUES (1314, 'Distrito Capital', 'Urbanización Prados De Maria', 1040);
INSERT INTO `zonas_postales` VALUES (1315, 'Distrito Capital', 'Urbanización Propatria', 1030);
INSERT INTO `zonas_postales` VALUES (1316, 'Distrito Capital', 'Urbanización Quinta Crespo', 1010);
INSERT INTO `zonas_postales` VALUES (1317, 'Distrito Capital', 'Urbanización Ruiz Pineda', 1000);
INSERT INTO `zonas_postales` VALUES (1318, 'Distrito Capital', 'Urbanización Sabana Grande', 1050);
INSERT INTO `zonas_postales` VALUES (1319, 'Distrito Capital', 'Urbanización San Agustin Del Norte', 1010);
INSERT INTO `zonas_postales` VALUES (1320, 'Distrito Capital', 'Urbanización San Agustin Del Sur', 1010);
INSERT INTO `zonas_postales` VALUES (1321, 'Distrito Capital', 'Urbanización San Antonio El Valle', 1040);
INSERT INTO `zonas_postales` VALUES (1322, 'Distrito Capital', 'Urbanización San Antonio Sabana Grande', 1050);
INSERT INTO `zonas_postales` VALUES (1323, 'Distrito Capital', 'Urbanización San Bernardino', 1010);
INSERT INTO `zonas_postales` VALUES (1324, 'Distrito Capital', 'Urbanización San Jose Del Avila', 1010);
INSERT INTO `zonas_postales` VALUES (1325, 'Distrito Capital', 'Urbanización San Luis', 1061);
INSERT INTO `zonas_postales` VALUES (1326, 'Distrito Capital', 'Urbanización San Marino', 1060);
INSERT INTO `zonas_postales` VALUES (1327, 'Distrito Capital', 'Urbanización San Martín', 1020);
INSERT INTO `zonas_postales` VALUES (1328, 'Distrito Capital', 'Urbanización San Michele', 1071);
INSERT INTO `zonas_postales` VALUES (1329, 'Distrito Capital', 'Urbanización San Román', 1061);
INSERT INTO `zonas_postales` VALUES (1330, 'Distrito Capital', 'Urbanización Santa Ana', 1061);
INSERT INTO `zonas_postales` VALUES (1331, 'Distrito Capital', 'Urbanización Santa Cecilia', 1071);
INSERT INTO `zonas_postales` VALUES (1332, 'Distrito Capital', 'Urbanización Santa Clara', 1061);
INSERT INTO `zonas_postales` VALUES (1333, 'Distrito Capital', 'Urbanización Santa Maria', 1071);
INSERT INTO `zonas_postales` VALUES (1334, 'Distrito Capital', 'Urbanización Santa Monica', 1040);
INSERT INTO `zonas_postales` VALUES (1335, 'Distrito Capital', 'Urbanización Santa Rosa', 1050);
INSERT INTO `zonas_postales` VALUES (1336, 'Distrito Capital', 'Urbanización Santa Rosa De Lima', 1061);
INSERT INTO `zonas_postales` VALUES (1337, 'Distrito Capital', 'Urbanización Sarria', 1050);
INSERT INTO `zonas_postales` VALUES (1338, 'Distrito Capital', 'Urbanización Simon Rodriguez', 1050);
INSERT INTO `zonas_postales` VALUES (1339, 'Distrito Capital', 'Urbanización Terraza De Caricuao', 1000);
INSERT INTO `zonas_postales` VALUES (1340, 'Distrito Capital', 'Urbanización Terraza De Santa Monica', 1040);
INSERT INTO `zonas_postales` VALUES (1341, 'Distrito Capital', 'Urbanización Urdaneta', 1030);
INSERT INTO `zonas_postales` VALUES (1342, 'Distrito Capital', 'Urbanización Valmore Rodriguez', 1000);
INSERT INTO `zonas_postales` VALUES (1343, 'Distrito Capital', 'Urbanización Valle Abajo', 1040);
INSERT INTO `zonas_postales` VALUES (1344, 'Distrito Capital', 'Urbanización Valle Alto', 1073);
INSERT INTO `zonas_postales` VALUES (1345, 'Distrito Capital', 'Urbanización Villa Zoila', 1020);
INSERT INTO `zonas_postales` VALUES (1346, 'Distrito Capital', 'Urbanización Vista Alegre', 1020);
INSERT INTO `zonas_postales` VALUES (1347, 'Distrito Capital', 'Urbanización Washington', 1020);
INSERT INTO `zonas_postales` VALUES (1348, 'Distrito Capital', 'Villa Croacia', 1162);
INSERT INTO `zonas_postales` VALUES (1349, 'Distrito Capital', 'Vista Al Mar', 1030);
INSERT INTO `zonas_postales` VALUES (1350, 'Distrito Capital', 'Otras Poblaciones o Sectores', 1020);

-- 
-- Filtros para las tablas descargadas (dump)
-- 

-- 
-- Filtros para la tabla `area_has_usuarios`
-- 
ALTER TABLE `area_has_usuarios`
  ADD CONSTRAINT `area_has_usuarios_ibfk_1` FOREIGN KEY (`id_area`) REFERENCES `area` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `area_has_usuarios_ibfk_2` FOREIGN KEY (`id_usuarios`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `asistencia_estudiante`
-- 
ALTER TABLE `asistencia_estudiante`
  ADD CONSTRAINT `asistencia_estudiante_ibfk_1` FOREIGN KEY (`id_estudiantes_bloques`) REFERENCES `estudiantes_bloques` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `becarios_asignados`
-- 
ALTER TABLE `becarios_asignados`
  ADD CONSTRAINT `becarios_asignados_ibfk_1` FOREIGN KEY (`id_estudiantes`) REFERENCES `estudiantes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `becarios_asignados_ibfk_2` FOREIGN KEY (`id_usuarios`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `bloques`
-- 
ALTER TABLE `bloques`
  ADD CONSTRAINT `bloques_ibfk_1` FOREIGN KEY (`id_dia`) REFERENCES `dias` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `coordinaciones1`
-- 
ALTER TABLE `coordinaciones1`
  ADD CONSTRAINT `coordinaciones1_ibfk_1` FOREIGN KEY (`id_area`) REFERENCES `area` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `coordinaciones1_has_usuarios`
-- 
ALTER TABLE `coordinaciones1_has_usuarios`
  ADD CONSTRAINT `coordinaciones1_has_usuarios_ibfk_1` FOREIGN KEY (`id_usuarios`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `datos_academicos_est`
-- 
ALTER TABLE `datos_academicos_est`
  ADD CONSTRAINT `datos_academicos_est_ibfk_2` FOREIGN KEY (`id_estudiante`) REFERENCES `estudiantes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `datos_academicos_est_ibfk_3` FOREIGN KEY (`id_trayecto`) REFERENCES `trayecto` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `depto_coord2_has_catedras`
-- 
ALTER TABLE `depto_coord2_has_catedras`
  ADD CONSTRAINT `depto_coord2_has_catedras_ibfk_1` FOREIGN KEY (`id_catedra`) REFERENCES `catedras` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `depto_coord2_has_catedras_ibfk_2` FOREIGN KEY (`id_depto_coord2`) REFERENCES `depto_coord2` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `depto_coord2_has_usuarios`
-- 
ALTER TABLE `depto_coord2_has_usuarios`
  ADD CONSTRAINT `depto_coord2_has_usuarios_ibfk_1` FOREIGN KEY (`id_deptocoord2`) REFERENCES `depto_coord2` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `depto_coord2_has_usuarios_ibfk_2` FOREIGN KEY (`id_usuarios`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `desincorporaciones`
-- 
ALTER TABLE `desincorporaciones`
  ADD CONSTRAINT `desincorporaciones_ibfk_1` FOREIGN KEY (`id_estudiantes`) REFERENCES `estudiantes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `desincorporaciones_ibfk_2` FOREIGN KEY (`id_tipo_desincorporaciones`) REFERENCES `tipo_desincorporaciones` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `estudiantes`
-- 
ALTER TABLE `estudiantes`
  ADD CONSTRAINT `estudiantes_ibfk_1` FOREIGN KEY (`id_edocivil`) REFERENCES `estado_civil` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `estudiantes_ibfk_2` FOREIGN KEY (`id_zona`) REFERENCES `zonas_postales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `estudiantes_bloques`
-- 
ALTER TABLE `estudiantes_bloques`
  ADD CONSTRAINT `estudiantes_bloques_ibfk_1` FOREIGN KEY (`id_bloque`) REFERENCES `bloques` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `grupo_familiar2`
-- 
ALTER TABLE `grupo_familiar2`
  ADD CONSTRAINT `grupo_familiar2_ibfk_1` FOREIGN KEY (`id_parentesco`) REFERENCES `parentesco` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `grupo_familiar2_ibfk_2` FOREIGN KEY (`id_estudiante`) REFERENCES `estudiantes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `historial`
-- 
ALTER TABLE `historial`
  ADD CONSTRAINT `historial_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `inventario`
-- 
ALTER TABLE `inventario`
  ADD CONSTRAINT `inventario_ibfk_1` FOREIGN KEY (`id_material`) REFERENCES `material` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `inventario_ibfk_2` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `material`
-- 
ALTER TABLE `material`
  ADD CONSTRAINT `material_ibfk_1` FOREIGN KEY (`id_um`) REFERENCES `unidad_medida` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `profesor`
-- 
ALTER TABLE `profesor`
  ADD CONSTRAINT `profesor_ibfk_1` FOREIGN KEY (`id_dc_catedra`) REFERENCES `depto_coord2_has_catedras` (`id_depto_coord2`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `profesor_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `std_socioeconomico`
-- 
ALTER TABLE `std_socioeconomico`
  ADD CONSTRAINT `std_socioeconomico_ibfk_1` FOREIGN KEY (`id_tipo_vivienda`) REFERENCES `tipo_vivienda` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `std_socioeconomico_ibfk_2` FOREIGN KEY (`id_tenencia_vivienda`) REFERENCES `tenencia_vivienda` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `std_socioeconomico_ibfk_3` FOREIGN KEY (`id_tae`) REFERENCES `tae` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `tipo_solicitud`
-- 
ALTER TABLE `tipo_solicitud`
  ADD CONSTRAINT `tipo_solicitud_ibfk_1` FOREIGN KEY (`id_estudiantes`) REFERENCES `estudiantes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `usuario_iniciado`
-- 
ALTER TABLE `usuario_iniciado`
  ADD CONSTRAINT `usuario_iniciado_ibfk_1` FOREIGN KEY (`id_usuarios`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
