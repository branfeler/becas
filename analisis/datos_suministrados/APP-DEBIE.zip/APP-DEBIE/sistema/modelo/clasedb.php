<?php
	class clasedb{
		private $db;
		public function conectar(){
			$this->db=mysql_pconnect("localhost","root","root") or die ("No se pudo conectar con Mysql");
		if($this->db){
			mysql_select_db("conpa");
			}
		}
		public function cerrar(){
			mysql_close($this->db);
		}
		public function consultas($sql){
			$resultado=mysql_query($sql);
			return $resultado;
			}
		}
?>
