<?php
session_start();
require_once("../validacion/bloqueDeSeguridad.php");
require_once("../modelo/clasedb.php");

class Usuarios{
  	public $id_usuario;
	private $login;
	private $clave2;
	private $clave;
	private $clave_anterior;
	public $cambiar;
	private $tipocuenta;
	private $nombres;
	private $nacio;
	private $cedula;
	private $pregunta;
	private $respuesta;
	
function __construct($id_usuario,$login,$clave,$clave2,$tipocuenta,$clave_anterior,$cambiar,$nombres,$nacio,$cedula,$pregunta,$respuesta) {
    $this->id_usuario = $id_usuario;	
    $this->login = $login;
	$this->clave2=$clave2;
    $this->clave = $clave;
	$this->tipocuenta = $tipocuenta;
	$this->cambiar = $cambiar;
	$this->clave_anterior = $clave_anterior;
	$this->nombres = $nombres;
	$this->nacio = $nacio;
	$this->cedula = $cedula;
	$this->pregunta = $pregunta;
	$this->respuesta = $respuesta;
}

//Insertar
public function insertar(){
	$db = new clasedb();
    $db->conectar();
	$sq="SELECT * FROM usuarios WHERE login='".$this->login."'";
	$r1= $db->consultaS($sq);
	$num=mysql_num_rows($r1);
	$num2=Usuarios::buscar2($this->cedula);
	
	//----- validando la contrasena
	 if(strlen($this->clave) < 8){
      $error_clave1 = "La clave debe tener al menos 8 caracteres";
   }
   if(strlen($this->clave) > 16){
      $error_clave2 = "La clave no puede tener más de 16 caracteres";
   }
   if (!preg_match('`[a-z]`',$this->clave)){
      $error_clave3 = "La clave debe tener al menos una letra minúscula";
   }
   if (!preg_match('`[A-Z]`',$this->clave)){
      $error_clave4 = "La clave debe tener al menos una letra mayúscula";
   }
   if (!preg_match('`[0-9]`',$this->clave)){
      $error_clave5 = "La clave debe tener al menos un caracter numérico";
   }
	if($error_clave1!="" || $error_clave2!="" || $error_clave3!="" || $error_clave4!="" || $error_clave5!=""  ){
	echo "<script> alert('!!! $error_clave1 $error_clave2 $error_clave3 $error_clave4 $error_clave5 !!!');
	             window.location='../vista/registroUsuarios.php?operaUsuarios=2&id_usuario=121213283238237823';
          </script>" ;
	}else{
	if($this->clave==$this->clave2){
	$clave=md5($this->clave);
	if($num>0){
	echo "<script> alert('!!! LOGIN YA REGISTRADO !!!');
	             window.location='../vista/registroUsuarios.php?operaUsuarios=2&id_usuario=121213283238237823';
          </script>" ;
	}else{
	if($num2>0){
	echo "<script> alert('!!! CEDULA YA REGISTRADA !!!');
	             window.location='../vista/registroUsuarios.php?operaUsuarios=2&id_usuario=121213283238237823';
          </script>" ;
	}else{
$sql = "INSERT INTO usuarios values (
		'null',
		'".$this->nombres."',
		".$this->cedula.",
		'".$this->nacio."',
		'".$this->login."',
		'".$clave."',
		'".$this->pregunta."',
		'".$this->respuesta."',
		'".$this->tipocuenta."');";
//echo $sql;
	
$r = $db->consultaS($sql);
$sqlh="INSERT INTO historial VALUES ('null',".$_SESSION['id_usu'].",'SE REGISTRO A UN USUARIO CON EL LOGIN ".$this->login."','".date('d-m-Y')."','".date('h:i')."')";
$hist=mysql_query($sqlh);
return   $r;
}//fin de la validacion de login repetido
	}//fin de la validacion de cedula repetida
}else{
	echo "<script> alert('!!! LAS CLAVES NO COINCIDEN !!!');
	             window.location='../vista/registroUsuarios.php?operaUsuarios=2&id_usuario=121213283238237823';
          </script>" ;
	}
  }
}	

public static function eliminar($id_usuario){
$db = new clasedb();
$db->conectar();
$sql="DELETE FROM usuarios WHERE id=".$id_usuario."";
//echo $sql;
	    
  $r = $db->consultaS($sql);
  if($r){
  $sql="DELETE FROM usuario_iniciado WHERE id=".$id_usuario."";
//echo $sql;
	    
  $r2 = $db->consultaS($sql);
  if($r2){
  $sqlh="INSERT INTO historial VALUES ('null',".$_SESSION['id_usu'].",'SE ELIMINO A UN USUARIO CON EL ID: ".$id_usuario."','".date('d-m-Y')."','".date('h:i')."')";
$hist=mysql_query($sqlh);
  return true;
  }else{return false;}
  }else{return false;}
}

public function modificar(){
	$db = new clasedb();
    $db->conectar();
	// buscando login ya registrado
	$sq="SELECT * FROM usuarios WHERE login='".$this->login."' and id<>".$this->id_usuario."";
	$r1= $db->consultaS($sq);
	$num=mysql_num_rows($r1);
	//buscando cedula ya registrada
	$sq2="SELECT * FROM usuarios WHERE cedula='".$this->cedula."' and id<>".$this->id_usuario."";
	$r2= $db->consultaS($sq2);
	$num2=mysql_num_rows($r2);

		//validando la contraseña
		 if(strlen($this->clave) < 8){
      $error_clave1 = "La clave debe tener al menos 8 caracteres";
   }
   if(strlen($this->clave) > 16){
      $error_clave2 = "La clave no puede tener más de 16 caracteres";
   }
   if (!preg_match('`[a-z]`',$this->clave)){
      $error_clave3 = "La clave debe tener al menos una letra minúscula";
   }
   if (!preg_match('`[A-Z]`',$this->clave)){
      $error_clave4 = "La clave debe tener al menos una letra mayúscula";
   }
   if (!preg_match('`[0-9]`',$this->clave)){
      $error_clave5 = "La clave debe tener al menos un caracter numérico";
   }
   //echo $this->cambiar."--";
	//------si se decidio modificar la clave
		if($this->cambiar==1){
		if($error_clave1!="" || $error_clave2!="" || $error_clave3!="" || $error_clave4!="" || $error_clave5!=""  ){
	echo "<script> alert('!!! $error_clave1 $error_clave2 $error_clave3 $error_clave4 $error_clave5 !!!');
          </script>" ;
// window.location='../vista/registroUsuarios.php?operaUsuarios=2&id_usuario=121213283238237823';		
	}else{
		$sql2="SELECT * FROM usuarios WHERE id=".$this->id_usuario."";
	//echo $sql2;
		$rs=mysql_query($sql2);
		while($datos=mysql_fetch_object($rs)){
		$clave_a=$datos->clave;
		}
		//----- verificando que la clave anterior sea la correcta
		//echo $this->clave_anterior."ojooo<br>";
		$clav=md5($this->clave_anterior);
		//echo $clave_a."-".$clav;
				if($clave_a==$clav){
		if($this->clave==$this->clave2){
			if($num>0){
	echo "<script> alert('!!! LOGIN YA REGISTRADO !!!');
          </script>" ;
//	             window.location='../vista/registroUsuarios.php?operaUsuarios=2&id_usuario=121213283238237823';
	}else{
	if($num2>0){
	echo "<script> alert('!!! CEDULA YA REGISTRADA !!!');
          </script>" ;
//	             window.location='../vista/registroUsuarios.php?operaUsuarios=2&id_usuario=121213283238237823';
	}else{
		//echo $this->clave;
		$clave=md5($this->clave);
		//---------- actualizando en caso de querer actualizar la clave
		$sql = "UPDATE usuarios SET  
		nombres = '".$this->nombres."',
		nacio = '".$this->nacio."',
		cedula = ".$this->cedula.",
		login = '".$this->login."',
		clave = '".$clave."',
		pregunta = '".$this->pregunta."',
		respuesta = '".$this->respuesta."',
		tipocuenta = '".$this->tipocuenta."'
		WHERE id = ".$this->id_usuario." LIMIT 1";

//echo $sql; 
$r = $db->consultaS($sql);
$sqlh="INSERT INTO historial VALUES ('null',".$_SESSION['id_usu'].",'SE MODIFICARON LOS DATOS DEL USUARIO INCLUYENDO SU CLAVE, CON EL LOGIN ".$this->login."','".date('d-m-Y')."','".date('h:i')."')";
$hist=mysql_query($sqlh);
return $r;
		}//fin de la validacion de login existente
				}//fin de la validacion si la cedula existe
		}else{
	echo "<script> alert('!!! LAS CLAVES NO COINCIDEN !!!');
	             window.location='../vista/registroUsuarios.php?operaUsuarios=2&id_usuario=$this->id_usuario';
          </script>" ;
		}
		}else{
	echo "<script> alert('!!! LA CLAVE ANTERIOR NO ES CORRECTA !!!');
	             window.location='../vista/registroUsuarios.php?operaUsuarios=2&id_usuario=$this->id_usuario';
          </script>" ;
		}
	}
		}else{
		//---------- actualizando en caso de no querer actualizar la clave
		$sql = "UPDATE usuarios SET 
		nombres = '".$this->nombres."',
		nacio = '".$this->nacio."',
		cedula = ".$this->cedula.", 
		login = '".$this->login."',
		pregunta = '".$this->pregunta."',
		respuesta = '".$this->respuesta."',
		tipocuenta = '".$this->tipocuenta."'
		WHERE id = ".$this->id_usuario." LIMIT 1";

//echo $sql; 
$r = $db->consultaS($sql);
return $r;
		}
}

public static function buscar($id_usuario){
	$db = new clasedb();
	$db->conectar();
    $sql = "SELECT * FROM usuarios where id=".$id_usuario;
//echo $sql;
$result = $db->consultaS($sql);
	return $result;
	}

public static function buscar2($cedula){
	$db = new clasedb();
	$db->conectar();
    $sql = "SELECT * FROM usuarios where cedula=".$cedula;
	$result = $db->consultaS($sql);
	$result = mysql_num_rows($result);
	return $result;
	}

public static function formBuscarUsuarios(){
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>GeSeNe</title>
<link href="../css/style.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript" src="../js/js.js"></script>
<link href="../css3/paginacion.css" type="text/css" rel="stylesheet">
<link href="../bootstrap/css_I/bootstrap.min.css" rel="stylesheet" media="screen">
<link href="../bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
<link href="../assets/styles.css" rel="stylesheet" media="screen">
<style>
body{
	font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;
	color:#666;
}
td{
	height:20px;
}
</style>
</head>
<body>
	<div class="container-fluid">	<!--	container-fluid -->
    	<div class="row-fluid">
			<div class="span12" id="content">   <!-- FORMULARIO -->
                <form method="post" name="buscarUsuarios">
                <table width="700px" border="0" align="center">
                  <tr height="60px" >
                    <td width="400px">Seleccione el modo de B&uacute;squeda de los Usuarios</td>
                    <td width="150px">
                    <select name="tipoB" id="tipoB" style="width:130px;">
                        <option value="1">Nombre</option>
                        <option value="2">C&eacute;dula</option>
                        <option value="3">Login</option>
                     </select>
                    </td>
                    <td width="150px">
                        <input type="text" name="nombre" id="nombre" onKeyUp="buscarUsuarioAJAX('mostrarInformacion','../controlador/controlador_usuario.php?operaUsuarios=5')"/ placeholder="Ingrese dato de b&uacute;squeda"></td>
                  </tr>
                </table>
                </form>
			</div>     	<!-- span9 -->
		</div>      
	</div>
<div id="mostrarInformacion" style="margin-top:50px;">
</div>
<script src="../vendors/jquery-1.9.1.min.js"></script>
<script src="../bootstrap/js_I/bootstrap.min.js"></script>
<script src="../assets/scripts.js"></script>
</body>
</html>
<?php
}	
public static function TipoBusqueda($tipoB,$nombre){
$db=new clasedb();
$db->conectar();
	switch($tipoB){
		case 1:
			$campo="usuarios.nombres";
		break;
		case 2:
			$campo="usuarios.cedula";
		break;
		case 3:
			$campo="usuarios.login";
		break;
	}
	
	if (isset($_GET["campo1"]))
	{
		$campo=$_GET["campo1"];
	}else
	{
		$campo;
	}
/////////////////////////////////////////////////////////////////////////////
//   http://blog.timersys.com/php/paginacion-con-php-y-mysql-3-estilos/   //
////////////////////////////////////////////////////////////////////////////
//INCLUYO LA HOJA DE ESTILOS
?>
<link href="../css3/paginacion.css" type="text/css" rel="stylesheet">
<link href="../bootstrap/css_I/bootstrap.min.css" rel="stylesheet" media="screen">
<link href="../bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
<link href="../assets/styles.css" rel="stylesheet" media="screen">
<style>
body{
	font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;
	color:#666;
}
td{
	height:20px;
}
</style>
<?php

//AL PRINCIPIO COMPRUEBO SI HICIERON CLICK EN ALGUNA P�GINA
if(isset($_GET['page'])){
    $page= $_GET['page'];
}else{
//SI NO DIGO Q ES LA PRIMERA P�GINA
    $page=1;
}

//ACA SE SELECCIONAN TODOS LOS DATOS DE LA TABLA
$consulta="SELECT * FROM usuarios WHERE ".$campo." LIKE '%".$nombre."%'";

//echo $consulta;
$datos=mysql_query($consulta);

//MIRO CUANTOS DATOS FUERON DEVUELTOS
$num_rows=mysql_num_rows($datos);

//ACA SE DECIDE CUANTOS RESULTADOS MOSTRAR POR P�GINA , EN EL EJEMPLO PONGO 15
$rows_per_page= 10;

//CALCULO LA ULTIMA P�GINA
$lastpage= ceil($num_rows / $rows_per_page);

//COMPRUEBO QUE EL VALOR DE LA P�GINA SEA CORRECTO Y SI ES LA ULTIMA P�GINA
$page=(int)$page;
if($page > $lastpage){
    $page= $lastpage;
}
if($page < 1){
    $page=1;
}

//CREO LA SENTENCIA LIMIT PARA A�ADIR A LA CONSULTA QUE DEFINITIVA
$limit= 'LIMIT '. ($page -1) * $rows_per_page . ',' .$rows_per_page;

//REALIZO LA CONSULTA QUE VA A MOSTRAR LOS DATOS (ES LA ANTERIO + EL $limit)
$consulta .=" $limit";
$rs=mysql_query($consulta);

if(!$rs){
        //SI FALLA LA CONSULTA MUESTRO ERROR
 die('Invalid query: ' . mysql_error());
}else{
      //SI ES CORRECTA MUESTRO LOS DATOS
      ?> 
      <table align="center" width="800px" >
        <thead>
        <caption style="font-weight:bold; font-size: 18px;">USUARIOS</caption>
	    <tr><th colspan="7" height="10px"></th></tr>
            <TH width="150px">NOMBRES</TH>
            <TH width="90px">C&Eacute;DULA</TH>
            <TH width="80px">LOGIN</TH>
            <TH width="120px">TIPO CUENTA</TH>
            <TH width="170px">PREGUNTA</TH>
            <TH width="140px">RESPUESTA</TH>
            <TH width="50px"></TH>
    <?php while($row = mysql_fetch_array($rs)){  ?>
        <tr><td><?php echo utf8_encode($row['nombres']); ?> </td>
        <td><?php echo $row['nacio']."-".$row['cedula']; ?></td>
        <td> <?php echo $row['login']; ?></td>
        <td><?php echo $row['tipocuenta']; ?></td>
        <td><?php echo utf8_encode($row['pregunta']); ?></td>
        <td><?php echo utf8_encode($row['respuesta']); ?></td>
		<?php if($_SESSION['tipocuentas']=="Administrador(a)"){ ?>
		<td>
            <a title="Modificar datos del Usuario" href="../vista/registroUsuarios.php?operaUsuarios=2&id_usuario=<?php echo $row['id'];?>" target="centro" style="text-decoration:none">
            <span class="glyphicon glyphicon-pencil" aria-hidden="true" title="Editar datos"></span></a>&nbsp;&nbsp;
            <a href="javascript:eliminar(<?php echo $row['id'];?>)" >
            <span class="glyphicon glyphicon-remove" aria-hidden="true" title="Eliminar datos"></span></a>
        </td>
       <?php }//fin del condicional
	  ?>
      </tr>
      <?php  
	   }//fin del while ?>
      </tbody>
      </table>
	  <br>
<?php //UNA VEZ Q MUESTRO LOS DATOS TENGO Q MOSTRAR EL BLOQUE DE PAGINACI�N SIEMPRE Y CUANDO HAYA M�S DE UNA P�GINA
   $nextpage= $page +1;
   $prevpage= $page -1;
?><ul id="pagination-digg" style="border:1px solid blue;width:300px;margin:0px auto;">
<li class="previous">
	<a href="clasedb.php?operaciones=2" target="_self" >
    <span class="glyphicon glyphicon-search" aria-hidden="true" title="Buscar"></span></a>
	<!--<a href="clasedb.php?operaciones=4" target="_self">Buscar</a>-->
</li>
<?php //SI ES LA PRIMERA P�GINA DESHABILITO EL BOTON DE Anterior, MUESTRO EL 1 COMO ACTIVO Y MUESTRO EL RESTO DE P�GINAS
 if ($page == 1) {
    ?>
      <li class="previous-off">&laquo; Anterior</li>
      <li class="active">1</li> <?php for($i= $page+1; $i<= $lastpage ; $i++){?>
            <li><a target="_self" href="../controlador/controlador_usuario.php?operaUsuarios=5&campo1=<?php echo $campo?>&nombre=<?php echo $nombre?>&page=<?php echo $i;?>&mostrar=1"><?php echo $i;?></a></li>
 <?php }
       //Y SI LA ULTIMA P�GINA ES MAYOR QUE LA ACTUAL MUESTRO EL BOTON Siguiente O LO DESHABILITO
    if($lastpage >$page ){?>       
      <li class="next">
      <a target="_self" href="../controlador/controlador_usuario.php?operaUsuarios=5&campo1=<?php echo $campo?>&nombre=<?php echo $nombre?>&page=<?php echo $nextpage;?>&mostrar=1" >Siguiente &raquo;</a></li><?php }else{?>
      <li class="next-off">Siguiente &raquo;</li>
<?php }
 } else {
    // EN CAMBIO SI NO ESTAMOS EN LA P�GINA UNO HABILITO EL BOTON DE PREVIUS Y MUESTRO LAS DEM�S
	?>
      <li class="previous"><a target="_self" href="../controlador/controlador_usuario.php?operaUsuarios=5&campo1=<?php echo $campo?>&nombre=<?php echo $nombre?>&page=<?php echo $prevpage;?>&mostrar=1"  >&laquo; Anterior</a></li><?php for($i= 1; $i<= $lastpage ; $i++){
                       //COMPRUEBO SI ES LA P�GINA ACTIVA O NO
            if($page == $i){
        ?>  <li class="active"><?php echo $i;?></li><?php }else{
        ?>  <li><a target="_self" href="../controlador/controlador_usuario.php?operaUsuarios=5&campo1=<?php echo $campo?>&nombre=<?php echo $nombre?>&page=<?php echo $i;?>&mostrar=1" ><?php echo $i;?></a></li><?php }
      }
         //SI NO ES LA �LTIMA P�GINA ACTIVO EL BOTON Siguiente    
      if($lastpage >$page ){    ?> 
      <li class="next"><a target="_self" href="../controlador/controlador_usuario.php?operaUsuarios=5&campo1=<?php echo $campo?>&nombre=<?php echo $nombre?>&page=<?php echo $nextpage;?>&mostrar=1">Siguiente &raquo;</a></li><?php }else{
    ?> <li class="next-off">Siguiente &raquo;</li><?php }
 }   
?></ul>
</div>
	<script src="../vendors/jquery-1.9.1.min.js"></script>
    <script src="../bootstrap/js_I/bootstrap.min.js"></script>
    <script src="../assets/scripts.js"></script>

<?php }
}//fin de la funcion tipoBusqueda
//------------------------------------------------------------------------------------------
}
//Cierro la Clase Usuarios
?>

