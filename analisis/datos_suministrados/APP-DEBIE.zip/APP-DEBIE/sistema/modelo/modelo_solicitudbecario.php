<?php
session_start();
require_once("../validacion/bloqueDeSeguridad.php");
require("clasedb.php");

class Inquilino{
  
   
   private $id_estudiantes;
   private $apellido1;
   private $apellido2;
   private $nombre1;
   private $nombre2;
   private $lugar_nac;
   private $fecha_nac;
   private $nacio;
   private $cedula;
   private $sexo;
   private $id:edocivil;
   private $condiciones;
   private $codigo_telf;
   private $telf_cel;
   private $telf_resi;
   private $id_zona;
   private $direccion;
   private $av_calle;
   private $nro_vivienda;
   private $email;
   private $facebook;
   private $twitter;
   
   public function __construct($id_estudiantes,$apellido1,$apellido2,$nombre1,$nombre2,lugar_nac,fecha_nac,nacio,$cedula,$sexo,$id_edocivil,$condiciones,$codigo_telf,$telf_cel,$telf_resi,$id_zona,$direccion,$av_calle,$nro_vivienda,$email,$facebook,$twitter)
 {
   
   $this->id_estudintes=$id_estudiantes;
   $this->apellido1=$apellido1;
   $this->apellido2=$apellido2;
   $this->nombre1=$nombre1;
   $this->nombre2=$nombre2;
   $this->lugar_nac=$lugar_nac;
   $this->fecha_nac=$fecha_nac;
   $this->nacio=$nacio;
   $this->cedula=$cedula;
   $this->sexo=$sexo;
   $this->id_edocivil=$id_edocivil;
   $this->condiciones=$condiciones;
   $this->codigo_telf=$codigo_telf;
   $this->telf_cel=$telf_cel;
   $this->telf_resi=$telf_resi;
   $this->id_zona=$id_zona;
   $this->direccion=$direccion;
   $this->av_calle=$av_calle;
   $this->nro_vivienda=$nro_vivienda;
   $this->email=$email;
   $this->facebook=$facebook;
   $this->twitter=$twitter;
   
   }
   public static function buscar($id_estudiantes){
   
   $db=new clasedb();
   $db->conectar();
   
   $sql="SELECT * FROM estudiantes,apartamentos WHERE estudiantes.id_estudiantes=estudiantes.id and inquilino.id_datos_basicos=datos_basicos.id and inquilino.id=".$id_estudiantes."";
  // echo $sql;
   $rs=mysql_query($sql);
   return $rs;
   } //fin de la funcion buscar.
//inicio de la funcion insertar
    public function insertar(){
	$db=new clasedb();
	$db->conectar();
	
	$sql="SELECT * FROM estudiantes WHERE id_estudiantes=".$this->id_estudiantes." and id<>".$this->id_estudiantes."";
	//echo $sql;
	$r=mysql_query($sql);
	$n=mysql_num_rows($r);
	if($n>0){
?>
<script language="javascript" type="text/javascript">
alert("El estudiante yase encuentra registrado");
window.open("../vista/solicitudbecario.php?operaEstudiantes=2&id_estudiantes=2345678654323456787654","_self");
</script>
<?php 	
	}else{
	$sql="SELECT * FROM estudiantes WHERE cedula=".$this->cedula."";
	$rs=mysql_query($sql);
	$n2=mysql_num_rows($rs);
	if($n2>0){
?>
<script language="javascript" type="text/javascript">
alert("Cedula ya registrada");
window.open("../vista/solicitudbecario.php?operaEstudiantes=2&id_estudiantes=2345678654323456787654","_self");
</script>
<?php 	
	}else{
	
	$sql="INSERT INTO estudiantes VALUES('null','".$this->nombre1."','".$this->nombre2."','".$this->apellido1."','".$this->apellido2."','".$this->lugar_nac."','".$this->fecha_nac."','".$this->nacio."',".$this->cedula.",'".$this->sexo."','".$this->id_edocivil."','".$this->condiciones."','".$this->codigo_telf."','".$this->telf_cel."','".$this->telf_resi"','".$this->id_zona."','".$this->direccion."','".$this->av_calle."','".$this->nro_vivienda."','".$this->email."','".$this->facebook."','".$this->twitter."');";
	
}
}//fin de la funcion insertar.



?>
