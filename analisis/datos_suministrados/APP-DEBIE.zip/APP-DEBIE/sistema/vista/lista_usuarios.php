<?php
session_start();
include("../validacion/bloqueDeSeguridad.php");
include("../modelo/clasedb.php");
$db=new clasedb();
$db->conectar();
?>

<div class="row">
	<div id="breadcrumb" class="col-xs-12">
		<a href="#" class="show-sidebar">
			<i class="fa fa-bars"></i>
		</a>
		<ol class="breadcrumb pull-left">
			<li><a href="#">Men&uacute;</a></li>
			<li><a href="#">Listas</a></li>
			<li><a href="#">Usuarios</a></li>
		</ol>
		<div id="social" class="pull-right">
			<a href="#"><i class="fa fa-google-plus"></i></a>
			<a href="#"><i class="fa fa-facebook"></i></a>
			<a href="#"><i class="fa fa-twitter"></i></a>
			<a href="#"><i class="fa fa-linkedin"></i></a>
			<a href="#"><i class="fa fa-youtube"></i></a>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-xs-12">
		<div class="box">
			<div class="box-header">
				<div class="box-name">
					<span>Lista de Usuarios Registrados</span>
				</div>
				<div class="box-icons">
					<a class="collapse-link">
						<i class="fa fa-chevron-up"></i>
					</a>
					<a class="expand-link">
						<i class="fa fa-expand"></i>
					</a>
					<a class="close-link">
						<i class="fa fa-times"></i>
					</a>
				</div>
				<div class="no-move"></div>
			</div>
			<div class="box-content no-padding">
				<table class="table table-bordered table-striped table-hover table-heading table-datatable" id="datatable-1">
					<thead>
						<tr>
							<th>Nro</th>
							<th>Nombres</th>
							<th>C&eacute;dula</th>
							<th>Login</th>
							<th>Tipo de Cuenta</th>
							<?php if($_SESSION["tipocuentas"]=="Administrador(a)"){ ?>
							<th>Pregunta</th>
							<th>Respuesta</th>
							<th>Opciones</th>
							<?php } ?>
						</tr>
					</thead>
					<tbody>
					<!-- Start: list_row -->

					<?php
					$sql="SELECT * FROM usuarios";
					$rs=mysql_query($sql);
					$i=1;
					while($data=mysql_fetch_object($rs)){
					?>
						<tr>
							<td><?=$i?></td>
							<td><?=$data->nombres?></td>
							<td><?=$data->nacio."-".$data->cedula?></td>
							<td><?=$data->login?></td>
							<td><?=$data->tipocuenta?></td>
							<?php if($_SESSION["tipocuentas"]=="Administrador(a)"){ ?>
							<td><?=$data->pregunta?></td>
							<td><?=$data->respuesta?></td>
							<td><ul><a class="ajax-link" href="vista/registroUsuarios.php?operaUsuarios=2&id_usuario=<?=$data->id?>&condicion=1" target="_self">Modificar</a></td>
							<?php } ?>
						</tr>
					<?php } ?>	
					<!-- End: list_row -->
					</tbody>
					<tfoot>
						<tr>
							<th>Nro</th>
							<th>Nombres</th>
							<th>C&eacute;dula</th>
							<th>Login</th>
							<th>Pregunta</th>
							<th>Respuesta</th>
							<th>Tipo de Cuenta</th>
							<th>Opciones</th>
						</tr>
					</tfoot>
				</table>
			</div>
		</div>
	</div>
</div>


<div id="ajax-content"></div>
<script type="text/javascript">
// Run Datables plugin and create 3 variants of settings
function AllTables(){
	TestTable1();
	
	LoadSelect2Script(MakeSelect2);
}
function MakeSelect2(){
	$('select').select2();
	$('.dataTables_filter').each(function(){
		$(this).find('label input[type=text]').attr('placeholder', 'Search');
	});
}
$(document).ready(function() {
	// Load Datatables and run plugin on tables 
	LoadDataTablesScripts(AllTables);
	// Add Drag-n-Drop feature
	WinMove();
});
</script>
