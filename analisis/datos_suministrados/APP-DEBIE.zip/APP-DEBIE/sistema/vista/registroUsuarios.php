<?php
session_start();
include("../validacion/bloqueDeSeguridad.php");
include("../controlador/controlador_usuario.php");
?>
<div class="row">
	<div id="breadcrumb" class="col-xs-12">
		<a href="#" class="show-sidebar">
			<i class="fa fa-bars"></i>
		</a>
		<ol class="breadcrumb pull-left">
			<li><a href="index.html">Menu</a></li>
			<li><a href="#">Registro</a></li>
			<li><a href="#">Registro Usuario</a></li>
		</ol>
		<div id="social" class="pull-right">
			<a href="#"><i class="fa fa-google-plus"></i></a>
			<a href="#"><i class="fa fa-facebook"></i></a>
			<a href="#"><i class="fa fa-twitter"></i></a>
			<a href="#"><i class="fa fa-linkedin"></i></a>
			<a href="#"><i class="fa fa-youtube"></i></a>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-xs-12 col-sm-12">
		<div class="box">
			<div class="box-header">
				<div class="box-name">
					<i class="fa fa-search"></i>
					<span>Usuarios</span>
				</div>
				<div class="box-icons">
					<a class="collapse-link">
						<i class="fa fa-chevron-up"></i>
					</a>
					<a class="expand-link">
						<i class="fa fa-expand"></i>
					</a>
					<a class="close-link">
						<i class="fa fa-times"></i>
					</a>
				</div>
				<div class="no-move"></div>
			</div>
			<div class="box-content">
				<h4 class="page-header"><?php echo $msj." "; ?> Usuario</h4>
				<form class="form-horizontal" role="form" action="../controlador/controlador_usuarios.php" method="POST">
					
					<div class="form-group">
						<label class="col-sm-2 control-label">Nombre</label>
						<div class="col-sm-4">
							<input type="text" class="form-control" placeholder="Ej: Pedro Perez" data-toggle="tooltip" data-placement="bottom" title="Nombre y Apellido" name="nombres" value="<?=$nombres?>">
						</div>
						<label class="col-sm-2 control-label">Cédula</label>
						<div class="col-sm-4">
							<select style="width:50px;" class="populate placeholder" name="nacio" id="s2_country">
									<option value="V" <?php if($nacio=="V"){ ?> selected="selected" <?php } ?>>V</option>
									<option value="E" <?php if($nacio=="V"){ ?> selected="selected" <?php } ?>>E</option>
								</select>
								<input name="cedula" value="<?=$cedula?>" type="text" class="form-control" placeholder="Ej:12345678" data-toggle="tooltip" data-placement="bottom" title="Aqu&iacute; debe ingresar la c&eacute;dula">
						</div>
					</div>


					<div class="form-group">
						<label class="col-sm-2 control-label">Usuario</label>
						<div class="col-sm-4">
							<input type="text" class="form-control" placeholder="Ej: perezp " name="login" value="<?$login?>" title="Coloque un nombre de Usuario">
						</div>

						<?php if ($msj=="Modificando"){ ?>
					<div class="form-group">
						<div class="checkbox">
							<label>
							<input onchange="Activar()" type="checkbox" class="form-control" name="cambiar" value="1" title="modificar clave">
							</label>
						</div>
						<label class="col-sm-2 control-label"> Clave anterio </label>
						<div class="col-sm-4">
							<input type="password" class="form-control" placeholder="Ej: Abc1234#" name="clave_anterior" title="Clave anterior">
							
						</div>
					</div>
						<?php } ?>

						<label class="col-sm-2 control-label">Clave</label>
						<div class="col-sm-4">
							<input type="password" class="form-control" placeholder="Ej: Abc1234#" name="clave" title="Minimo 8 caracteres, minimo una letra mayuscula, al menos un numero y minimo un simbolo" >
							
						</div>
					</div>


					<div class="form-group">
						<label class="col-sm-2 control-label">Pregunta</label>
						<div class="col-sm-4">
							<input type="text" class="form-control" placeholder="Mi pregunta"  title="Coloque una Pregunta de Seguridad">
							
						</div>
						<label class="col-sm-2 control-label">Respuesta</label>
						<div class="col-sm-4">
							<input type="text" class="form-control" placeholder="Mi respuesta"  title="Coloque la Respuesta a su Pregunta de Seguridad">
							
						</div>
						<div class="form-group">
						<label class="col-sm-2 control-label">Tipo de Usuario</label>
						<div class="col-sm-4">
							<select  class="populate placeholder" name="tipocuenta" id="s2_with_tag" multiple="multiple">
								<?php if($_SESSION["tipocuentas"]=="Administrador(a)") { ?> 
								<option value="Administrador(a)" <?php if($tipocuenta=="Administrador(a)"){ ?> selected="selected" <?php } ?> >Administrador(a)</option> <?php } ?>
								<option value="Secretaria" <?php if($tipocuenta=="Secretaria"){ ?> selected="selected" <?php } ?> >Secretaria</option>
							</select>
						</div>
					</div>
					<div class="col-sm-offset-2 col-sm-2">

							<input type="hidden" nombre="id_usuario" value="<?=$id_usuario?>">
							<input type="hidden" nombre="operaUsuarios" value="<?=$operausuarios?>">

							<button type="cancel" class="btn btn-default btn-label-left" nombre="" value=""> 
							<span><i class="fa fa-clock-o txt-danger"></i></span>
								Limpiar
							</button>
 						</div>
<div class="col-sm-2">
							<button type="submit" class="btn btn-primary btn-label-left" nombre="" value=""> 
							<span><i class="fa fa-clock-o"></i></span>
								Enviar
							</button>
						</div>
				</form>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
// Run Select2 plugin on elements
function DemoSelect2(){
	$('#s2_with_tag').select2({placeholder: "Seleccione"});
	$('#s2_country').select2();
}
// Run timepicker
function DemoTimePicker(){
	$('#input_time').timepicker({setDate: new Date()});
}
$(document).ready(function() {
	// Create Wysiwig editor for textare
	TinyMCEStart('#wysiwig_simple', null);
	TinyMCEStart('#wysiwig_full', 'extreme');
	// Add slider for change test input length
	FormLayoutExampleInputLength($( ".slider-style" ));
	// Initialize datepicker
	$('#input_date').datepicker({setDate: new Date()});
	// Load Timepicker plugin
	LoadTimePickerScript(DemoTimePicker);
	// Add tooltip to form-controls
	$('.form-control').tooltip();
	LoadSelect2Script(DemoSelect2);
	// Load example of form validation
	LoadBootstrapValidatorScript(DemoFormValidator);
	// Add drag-n-drop feature to boxes
	WinMove();
});
</script>
