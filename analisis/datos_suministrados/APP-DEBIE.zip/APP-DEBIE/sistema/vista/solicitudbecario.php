<?php
session_start();
require_once("../validacion/bloqueDeSeguridad.php");
require("../controlador/controlador_solicitudbecario.php");



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Regitro de Inquilino</title>
</head>

<body>
<form action="../controlador/controlador_solicitudbecario.php" method="post" name="form"> 
<table>
<tr><td><a href="../sistema.php" target="_self">Inicio</a>&nbsp;&nbsp;<?php echo $mensaje; ?> Inquilino</td></tr>
<tr><td><strong>apellido1</strong></td><td><input type="text" required name="apellido1" placeholder="Perez" title="Ingrese su Primer apellido" value="<?php echo $apellido1; ?>" /></td></tr>
<tr><td><strong>apellido2</strong></td><td><input type="text" required name="apellido2" placeholder="Gonzalez" title="Ingrese su segundo apellido" value="<?php echo $apellido2; ?>" /></td></tr>
<tr><td><strong>nombre1</strong></td><td><input type="text" required name="nombre1" placeholder="Manuel" title="Ingrese su primer nombre" value="<?php echo $nombre1; ?>" /></td></tr>
<tr><td><strong>nombre2</strong></td><td><input type="text" required name="nombre2" placeholder="Manuel" title="Ingrese su segundo nombre" value="<?php echo $nombre2; ?>" /></td></tr>
<tr><td><strong>lugar_nac</strong></td><td><input type="text" required name="lugar_nac" placeholder="Manuel" title="lugar De Nacimiento" value="<?php echo $lugar_nac; ?>" /></td></tr>
<tr><td><strong>fecha_nac</strong></td><td><input type="text" required name="nombre1" placeholder="Manuel" title="Ingrese su primer nombre" value="<?php echo $nombre1; ?>" /></td></tr>

<tr><td><strong>nacio</strong></td><td><select name="nacionalidad">
<option value="V" <?php if($nacio=="V"){ ?> selected="selected" <?php } ?> >V</option>
<option value="E" <?php if($nacio=="E"){ ?> selected="selected" <?php } ?> >E</option>

</select><input type="text" name="cedula" required placeholder="C.I 13.458.972" maxlength="8" title="Numero de Cedula" value="<?php echo $cedula; ?>" /></td></tr>

<tr><td><strong>sexo</strong></td><td><select name="sexo">
<option value="F" <?php if($sexo=="F"){ ?> selected="selected" <?php } ?> >F</option>
<option value="M" <?php if($sexo=="M"){ ?> selected="selected" <?php } ?> >M</option>

<tr><td><strong>condiciones</strong></td><td><input type="text" required name="condiciones" placeholder="Condiciones de Salud" value=""<?php echo $condiciones; ?>" /></td></tr>
<tr><td><strong>codigo_telf</strong></td><td><input type="text" required name="codigo_telf" placeholder="" title="codigo de telefono" value=""<?php echo $codigo_telf; ?>" /></td></tr>




</td></tr>


<input name="operaSolicitudbecario" type="hidden" value="<?php echo $operaSolicitudbecario; ?>" />
<input name="id_estudiantes" type="hidden" value="<?php echo $id_estudiantes; ?>" />
<tr><td>
  <input type="submit" name="enviar" value="Enviar" /><input type="reset" name="limpiar" value="Limpiar" /></td></tr>


</table>
</body>
</html>

