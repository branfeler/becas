<?php 
//switch de operaciones 
include("../modelo/clase_usuarios.php");
extract($_REQUEST); //Extraigo las variables

//print_r($_REQUEST);
if (!empty($operaUsuarios)){ //Si operacion no esta vacia

//print_r($_REQUEST);

switch($operaUsuarios){ //Comienzo el switch

case 1:{ //operacion de Guardar

//Creo el objeto del tipo cliente
$objeto = new Usuarios($id_usuario, $login,$clave,$clave2,$tipocuenta,$clave_anterior,$cambiar,$nombres,$nacio,$cedula,$pregunta,$respuesta) ;

if ($objeto->insertar())  {
	echo "<SCRIPT language='javascript'> 
		if ( confirm('!!! REGISTRO INGRESADO !!! ') ) { 							
			window.location='../vista/registroUsuarios.php?operaUsuarios=2&id_usuario=234567654345678';
		}
	 	else { window.location='../contenido.php';  };
		</SCRIPT>";
}else {
	echo "<script> alert('!!! REGISTRO NO INGRESADO !!!');
             window.location='../contenido.php';
          </script>" ;
 }
break;	
} //Cierro el case 1 Guardar

case 2:{ //operacion 
if (strlen($id_usuario) > 0) {
	if ($result = Usuarios::buscar($id_usuario)){ //si trae Datos
 	   if (mysql_num_rows($result) == 1) {
    	    //Convierto Consulta en Arreglo
        	$fila = mysql_fetch_assoc($result);
            extract($fila);
			$id_usuario= $id_usuario;
		    $operaUsuarios=3;
			$msj="Modificando";

		} else { //si no trae datos
			$id_usuario= $id_usuario;
		    $operaUsuarios=1;
			$msj="Ingresando";
		}
	}
}
break;
}//Cierro el case 2 Buscar

case 3:{ //Modificar
//Creo el objeto del tipo usuario
$objeto = new Usuarios($id_usuario, $login,$clave,$clave2,$tipocuenta,$clave_anterior,$cambiar,$nombres,$nacio,$cedula,$pregunta,$respuesta);
if($objeto->cambiar==1 && $objeto->id_usuario==$_SESSION['id_usu']){
	if ($objeto->modificar()) {
		echo "<SCRIPT> alert('!!!REGISTRO MODIFICADO, SE CERRARA LA SESION POR EL CAMBIO DE CLAVE!!!');
			window.location='../validacion/salir.php'; </SCRIPT>";
	}
	else {
		echo "<script> alert('!!!REGISTRO NO MODIFICADO!!!');
	         window.location='../vista/registroUsuarios.php?operaUsuarios=2&id_usuario=$objeto->id_usuario';
        	</script>" ;
	}
}else{
	if ($objeto->modificar()) {
		echo "<SCRIPT> alert('!!!REGISTRO MODIFICADO!!!');
		window.location='../vista/registroUsuarios.php?operaUsuarios=2&id_usuario=234567654345678'; </SCRIPT>";
	}
	else {
		echo "<script> alert('!!!REGISTRO NO MODIFICADO!!!');
	        	window.location='../vista/registroUsuarios.php?operaUsuarios=2&id_usuario=$objeto->id_usuario';
        	</script>" ;
	}
}
break;	
}//Cierro el caso 3 modificar

case 4: {
if (Usuarios::eliminar($id_usuario)) {
	echo "<SCRIPT language='javascript'> alert ('!!! REGISTRO ELIMINADO !!!');
			window.location='./controlador_usuario.php?listados=2'; </SCRIPT>";
}
else {
	echo "<script> alert ('!!! REGISTRO NO ELIMINADO !!!');
              window.location='./controlador_usuario.php?listados=2';
          </script>" ;
}
break;
}//cierro el caso eliminar

case 5:
Usuarios::TipoBusqueda($tipoB,$nombre);
break;
}//Cierro el Switch
}//cierro si trae operacion



//------------------------------------------------------FUNCIONES ----------------------------------------------

function ListarUsuarios2(){
$db= new clasedb();
$db->conectar();
?>
<link href="../css3/paginacion.css" type="text/css" rel="stylesheet">
<link href="../bootstrap/css_I/bootstrap.min.css" rel="stylesheet" media="screen">
<link href="../bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
<link href="../assets/styles.css" rel="stylesheet" media="screen">
<style>
body{
	font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;
	color:#666;
}
td{
	height:20px;
}
</style>
<script >

function eliminar(id){
	if (confirm("!!! EL REGISTRO SERA ELIMINADO !!!") ) {
		window.open("./controlador_usuario.php?operaUsuarios=4&id_usuario="+id,"centro");
	}
}
</script>

<body>
<?php
//AL PRINCIPIO COMPRUEBO SI HICIERON CLICK EN ALGUNA P�GINA
if(isset($_GET['page'])){
    $page= $_GET['page'];
}else{
//SI NO DIGO Q ES LA PRIMERA P�GINA
    $page=1;
}

//ACA SE SELECCIONAN TODOS LOS DATOS DE LA TABLA
$consulta="SELECT * FROM usuarios";
$datos=mysql_query($consulta);

//MIRO CUANTOS DATOS FUERON DEVUELTOS
$num_rows=mysql_num_rows($datos);

//ACA SE DECIDE CUANTOS RESULTADOS MOSTRAR POR P�GINA , EN EL EJEMPLO PONGO 15
$rows_per_page= 10;

//CALCULO LA ULTIMA P�GINA
$lastpage= ceil($num_rows / $rows_per_page);

//COMPRUEBO QUE EL VALOR DE LA P�GINA SEA CORRECTO Y SI ES LA ULTIMA P�GINA
$page=(int)$page;
if($page > $lastpage){
    $page= $lastpage;
}
if($page < 1){
    $page=1;
}

//CREO LA SENTENCIA LIMIT PARA A�ADIR A LA CONSULTA QUE DEFINITIVA
$limit= 'LIMIT '. ($page -1) * $rows_per_page . ',' .$rows_per_page;

//REALIZO LA CONSULTA QUE VA A MOSTRAR LOS DATOS (ES LA ANTERIO + EL $limit)
$consulta .=" $limit";
$res=mysql_query($consulta);

if(!$res){
        //SI FALLA LA CONSULTA MUESTRO ERROR
 die('Invalid query: ' . mysql_error());
}else{
      //SI ES CORRECTA MUESTRO LOS DATOS
      ?><table width="650px" align="center" style="font-size:14px">
        <thead>
        <caption style="font-weight:bold; font-size: 18px;">LISTA DE USUARIOS</caption>
	    <tr><th colspan="6" height="10px"></th></tr>
        <tr><th width="30px">N�</th>
        <th width="200px">NOMBRE</th>
        <th width="120px">C&Eacute;DULA</th>
        <th width="120px">LOGIN</th>
        <th width="120px">TIPO CUENTA</th>
        <th width="60px"></th>
        </tr>
        </thead>
        <tbody>
    <?php
	$p=1;
	 while($row = mysql_fetch_array($res)){  
	 	if(($p%2)==0)
		{
	?>
        <tr>
	<?php
		}
		else
		{
	?>
        <tr bgcolor="#EAEAEA">
     <?php   
        }
	?>
        <td><?php echo $p; ?> </td>
        <td> <?php echo $row['nombres']; ?> </td>
        <td> <?php echo $row['nacio']."-".$row['cedula']; ?> </td>
        <td> <?php echo $row['login']; ?> </td>
        <td> <?php echo $row['tipocuenta']; ?> </td>
        <td align="center"><?php if($_SESSION['tipocuentas']=="Administrador(a)"){?>
        <a href="../vista/registroUsuarios.php?operaUsuarios=2&id_usuario=<?php echo $row['id'];?>" target="centro" style="text-decoration:none">
       	<span class="glyphicon glyphicon-pencil" aria-hidden="true" title="Editar datos"></span></a>&nbsp;&nbsp;
		<a href="javascript:eliminar(<?php echo $row['id'];?>)" >
        <span class="glyphicon glyphicon-remove" aria-hidden="true" title="Eliminar datos"></span></a>
		<?php } ?></td></tr>
       <?php $p++; 
		
	 }?>
      </tbody>
      </table>
	  <br>
<?php
//UNA VEZ Q MUESTRO LOS DATOS TENGO Q MOSTRAR EL BLOQUE DE PAGINACI�N SIEMPRE Y CUANDO HAYA M�S DE UNA P�GINA
   $nextpage= $page +1;
   $prevpage= $page -1;
?><ul id="pagination-digg" style="border:1px solid blue;width:300px;margin:0px auto;">
<li class="previous">
	<a href="clasedb.php?operaciones=4" target="_self" >
    <span class="glyphicon glyphicon-search" aria-hidden="true" title="Buscar"></span></a>
	<!--<a href="clasedb.php?operaciones=4" target="_self">Buscar</a>-->
</li>
<?php

//SI ES LA PRIMERA P�GINA DESHABILITO EL BOTON DE Anterior, MUESTRO EL 1 COMO ACTIVO Y MUESTRO EL RESTO DE P�GINAS
 if ($page == 1) {
    ?>
      <li class="previous-off">&laquo; Anterior</li>
      <li class="active">1</li> <?php
    for($i= $page+1; $i<= $lastpage ; $i++){?>
            <li><a href="../controlador/controlador_usuario.php?listados=2&page=<?php echo $i;?>" target="centro"><?php echo $i;?></a></li>
 <?php }
       //Y SI LA ULTIMA P�GINA ES MAYOR QUE LA ACTUAL MUESTRO EL BOTON Siguiente O LO DESHABILITO
    if($lastpage >$page ){?>       
      <li class="next"><a href="../controlador/controlador_usuario.php?listados=2&page=<?php echo $nextpage;?>" target="centro" >Siguiente &raquo;</a></li><?php
    }else{?>
      <li class="next-off">Siguiente &raquo;</li>
<?php  }
 } else {
    // EN CAMBIO SI NO ESTAMOS EN LA P�GINA UNO HABILITO EL BOTON DE PREVIUS Y MUESTRO LAS DEM�S
	?>
    
      <li class="previous"><a href="../controlador/controlador_usuario.php?listados=2&page=<?php echo $prevpage;?>" target="centro"  >&laquo; Anterior</a></li><?php
      for($i= 1; $i<= $lastpage ; $i++){
                       //COMPRUEBO SI ES LA P�GINA ACTIVA O NO
            if($page == $i){
        ?>  <li class="active"><?php echo $i;?></li><?php
            }else{
        ?>  <li><a href="../controlador/controlador_usuario.php?listados=2&page=<?php echo $i;?>" target="centro" ><?php echo $i;?></a></li><?php
            }
      }
         //SI NO ES LA �LTIMA P�GINA ACTIVO EL BOTON Siguiente    
      if($lastpage >$page ){    ?> 
      <li class="next"><a href="../controlador/controlador_usuario.php?listados=2&page=<?php echo $nextpage;?>" target="centro">Siguiente &raquo;</a></li><?php
      }else{
    ?> <li class="next-off">Siguiente &raquo;</li><?php
      }
 }   
?></ul>
</div>
<?php
}
echo"</center> "; ?>       
<script src="../vendors/jquery-1.9.1.min.js"></script>
<script src="../bootstrap/js_I/bootstrap.min.js"></script>
<script src="../assets/scripts.js"></script>
<?php
echo"</body>";
}
if ($listados== "2") listarUsuarios2();

?>