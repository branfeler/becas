<?php
session_start();
require("../controlador/modelo_solicitudbecario.php");

extract($_REQUEST);

if(!empty ($operaEstudiantes)){
 
switch ($operaEstudiantes){

case 1:

$obj=new Solicitudbecario($id_estudiantes,$apellido1,$apellido2,$nombre1,$nombre2,lugar_nac,fecha_nac,nacio,$cedula,$sexo,$id_edocivil,$condiciones,$codigo_telf,$telf_cel,$telf_resi,$id_zona,$direccion,$av_calle,$nro_vivienda,$email,$facebook,$twitter);

if($obj->insertar()){

?>
<script type="text/javascript" language="javascript">
if(confirm("Registro Ingresado!!! Desea Registrar otro?")){
window.open("../vista/solicitudbecario.php?operaEstudiantes=2&id_estudiantes=23456786543234567654345","_self");
}else{
window.open("../sistema.php","_self");
}
</script>
<?php
}else{
?>
<script type="text/javascript" language="javascript">
alert("Registro no Ingresado");
window.open("../vista/solicitudbecario.php?operaEstudiantes=2&id_estudiantes=23456786543234567654345","_self");
</script> 

<?php
}
break;
case 2:
//buscando el id del estudiante
if(!empty($id_estudiantes)){

if($resultado=Estudiantes::buscar($id_estudiantes)){

$n=mysql_num_rows($resultado);// reviso cuantos registros me trajo la consulta
if($n==1){

$registro=mysql_fetch_assoc($resultado);//guardo los registros en la variable registro

extract($registro);

$operaEstudiantes=4;
$id_estudiantes=$id_estudiantes;
$mensaje="Modificando";

}else{

$operaEstudiantes=1;
$mensaje="Registrando";


}

}



}

