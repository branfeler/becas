<?php
//Inicio la sesión
session_start();
//COMPRUEBA QUE EL USUARIO ESTA AUTENTICADO
if ($_SESSION["autenticado"] != "SI") 
{
//si no existe, va a la página de autenticacion
//header('Location: ../index.php');
?>
<script> 
	alert("!!! NO HA INICIADO SESION !!!");
	window.open("index.php","_self");
</script>
<?php
//salimos de este script
exit();
}
?>