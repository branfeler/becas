<?php
session_start();
include("../modelo/clasedb.php");
$db=new clasedb();
$db->conectar();
$sql="UPDATE usuario_iniciado SET estado='Inactivo' WHERE id_usuario=".$_SESSION['id_usu']." and estado='Activo'";
//echo $sql;
$rs=mysql_query($sql);
if($rs){
$sqlh="INSERT INTO historial VALUES ('null',".$_SESSION['id_usu'].",'EL USUARIO CON EL LOGIN ".$_SESSION['login']."' CERRO SU SESION,'".date('d-m-Y')."','".date('h:i')."')";
$hist=mysql_query($sqlh);
session_destroy();
?>

<script>
top.location.href="../index.php"
</script>
<?php
/*@header('Location: ../index.php');*/
}
?>