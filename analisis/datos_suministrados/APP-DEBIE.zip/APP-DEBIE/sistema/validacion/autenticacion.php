<?php
session_start();
require_once("../modelo/clasedb.php");
$db = new clasedb();
$db->conectar();
$num=1;
extract($_REQUEST);
if($num>=1){
//echo $_REQUEST['clave']."<br>";
	//echo $clave."<br>";
$clave=md5($_REQUEST['clave']);
	$sql="SELECT * FROM usuarios where login='".$_REQUEST['login']."' and clave='".$clave."'";
	$res = $db->consultaS($sql);
	//echo $sql;
	$num2=mysql_num_rows($res);
	if($num2>=1){
		while($per=mysql_fetch_array($res)){
			$_SESSION["id_usu"]=$per['id'];
			$_SESSION["login_usu"]=$per['login'];
			$_SESSION["tipocuentas"]=$per['tipocuenta'];
			$_SESSION["clave_usu"]=$per['clave'];
			$_SESSION["autenticado"]= "SI";
		}// while
	
	$sql3="SELECT * FROM usuario_iniciado WHERE id_usuario=".$_SESSION["id_usu"]." and estado='Activo'";
	$rs3=mysql_query($sql3);
	$cant=mysql_num_rows($rs3);
	if($cant>1){
		echo "<SCRIPT> alert('!!!EL USUARIO YA TIENE SU CUENTA INICIADA!!!');
					window.location='../index.php'; </SCRIPT>";
	}else{
	$sql2="INSERT INTO usuario_iniciado VALUE('null',".$_SESSION["id_usu"].",'Activo')";
	$rs=mysql_query($sql2);
	if($rs){
	$sqlh="INSERT INTO historial VALUES ('null',".$_SESSION['id_usu'].",'EL USUARIO CON EL LOGIN ".$_SESSION['login_usu']." HA INICIADO SESION','".date('d-m-Y')."','".date('h:i')."')";
	$hist=mysql_query($sqlh);
?>
<script>
	window.open("../sistema.php","_self");
</script>
    <?php	}// if ($rs)
		} // else
}// if $num2
else{
	echo "<SCRIPT> alert('!!!USUARIO INCORRECTO!!!');
    		window.location='../index.php'; </SCRIPT>";
}// if $num1
}else{
header ('Location: ../sistema.php');

}

?>